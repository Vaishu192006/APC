from django.shortcuts import render
import re

def login(request):
    msg = ""

    if request.method == "POST":
        username = request.POST.get("username", "")
        password = request.POST.get("password", "")

        if re.fullmatch(r'[a-zA-Z]+', username) and re.fullmatch(r'.{6,}', password):
            msg = "Login Successful"
        else:
            msg = "Invalid Username or Password"

    return render(request, 'login.html', {'msg': msg})