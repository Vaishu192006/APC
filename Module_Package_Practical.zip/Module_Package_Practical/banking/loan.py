# c) loan.py – loan calculation


def calculate_interest(principal, rate, years):
    interest = (principal * rate * years) / 100
    return interest


def calculate_total_amount(principal, rate, years):
    interest = calculate_interest(
        principal, rate, years
    )

    return principal + interest
