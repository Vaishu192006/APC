# b) transaction.py – deposit and withdrawal


def deposit(account, amount):
    account["balance"] = account["balance"] + amount
    return account["balance"]


def withdraw(account, amount):

    if amount <= account["balance"]:
        account["balance"] = account["balance"] - amount
        return account["balance"]

    else:
        print("Insufficient balance.")
        return account["balance"]
