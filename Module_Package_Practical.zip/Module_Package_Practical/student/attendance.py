# c) attendance.py – attendance eligibility


def attendance_percentage(present, total):
    return (present / total) * 100


def is_eligible(percentage):

    if percentage >= 75:
        return True

    else:
        return False
