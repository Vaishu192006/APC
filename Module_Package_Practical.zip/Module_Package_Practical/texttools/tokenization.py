# b) tokenization.py – tokenize text


def tokenize(text):
    return text.split()
