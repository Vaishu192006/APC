from django.core.exceptions import ValidationError
from django.test import SimpleTestCase

from shop.services import validators as v


class ValidatorTests(SimpleTestCase):
    def test_email(self):
        self.assertEqual(v.validate_email(" Test@Example.com "), "test@example.com")
        for bad in ("abc", "a@b", "a b@c.com"):
            with self.assertRaises(ValidationError):
                v.validate_email(bad)

    def test_phone(self):
        self.assertEqual(v.validate_phone("98765 43210"), "9876543210")
        with self.assertRaises(ValidationError):
            v.validate_phone("12345")

    def test_password(self):
        v.validate_password("Passw0rd1")
        for bad in ("short1", "onlyletters", "12345678"):
            with self.assertRaises(ValidationError):
                v.validate_password(bad)

    def test_negative_values_rejected(self):
        with self.assertRaises(ValidationError):
            v.validate_price(-1)
        with self.assertRaises(ValidationError):
            v.validate_stock(-5)

    def test_formula_injection_blocked(self):
        with self.assertRaises(ValidationError):
            v.validate_text("=HYPERLINK('x')", "Text")

    def test_image_path_traversal_blocked(self):
        with self.assertRaises(ValidationError):
            v.validate_image_path("../../secret.png")
