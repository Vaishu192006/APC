from shop.storage import csv_store
from shop.storage.schemas import csv_path
from .base import TempDataTestCase


class CsvStoreTests(TempDataTestCase):
    def test_missing_file_is_created_with_header(self):
        csv_path("products").unlink()
        self.assertEqual(csv_store.read_rows("products"), [])
        self.assertTrue(csv_path("products").read_text().startswith("product_id,name"))

    def test_empty_file_is_repaired(self):
        csv_path("orders").write_text("")
        self.assertEqual(csv_store.read_rows("orders"), [])

    def test_malformed_rows_are_skipped(self):
        header = ",".join(csv_store.SCHEMAS["categories"])
        csv_path("categories").write_text(f"{header}\nC001,Books,ok\nBROKEN\nC002,Toys,x,extra,extra\n")
        self.assertEqual([r["category_id"] for r in csv_store.read_rows("categories")], ["C001"])

    def test_unique_ids_and_atomic_write(self):
        csv_store.append_row("categories", {"category_id": "C001", "name": "A", "description": ""})
        self.assertEqual(csv_store.next_id("categories"), "C002")
        self.assertFalse(list(self.tmp.glob("*.tmp")))     # no temp files left behind

    def test_unknown_file_name_is_rejected(self):
        with self.assertRaises(ValueError):
            csv_path("../../etc/passwd")
