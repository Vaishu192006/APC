"""Shared helper: every test uses its own temporary data folder (real data is never touched)."""
import shutil
import tempfile
from pathlib import Path

from django.test import SimpleTestCase, override_settings

from shop.services import auth_service, product_service
from shop.storage.csv_store import ensure_all


class TempDataTestCase(SimpleTestCase):
    def setUp(self):
        super().setUp()
        self.tmp = Path(tempfile.mkdtemp())
        self._override = override_settings(DATA_DIR=self.tmp)
        self._override.enable()
        ensure_all()
        auth_service.reset_login_limits()

    def tearDown(self):
        self._override.disable()
        shutil.rmtree(self.tmp, ignore_errors=True)
        super().tearDown()

    # ---- small builders ----
    def make_product(self, name="Test Pen", price=100.0, stock=5, category="Stationery"):
        cats = {c["name"]: c["category_id"] for c in product_service.list_categories()}
        if category not in cats:
            product_service.add_category(category)
            cats = {c["name"]: c["category_id"] for c in product_service.list_categories()}
        return product_service.create_product({
            "name": name, "description": f"{name} for writing", "category_id": cats[category],
            "price": price, "stock": stock, "image_path": ""})

    def make_customer(self, email="a@example.com", phone="9876543210", name="Asha Rao"):
        return auth_service.register_customer(name, email, phone, "Passw0rd1")

    def login(self, email="a@example.com", password="Passw0rd1"):
        return self.client.post("/login/", {"email": email, "password": password})
