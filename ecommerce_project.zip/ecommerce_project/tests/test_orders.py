"""End-to-end tests: register -> cart -> checkout -> stock -> cancel -> permissions."""
from shop.services import auth_service, cart_service, order_service, product_service
from shop.services.order_service import OrderError
from shop.storage.csv_store import read_rows, write_rows
from .base import TempDataTestCase


class FakeSession(dict):
    """Minimal stand-in for a Django session."""
    modified = False


class OrderFlowTests(TempDataTestCase):
    def setUp(self):
        super().setUp()
        self.product = self.make_product(price=100.0, stock=5)
        self.user = self.make_customer()
        self.token = "a" * 32

    def test_place_order_reduces_stock_and_adds_tax(self):
        order = order_service.place_order(self.user.customer_id, {self.product.product_id: 2}, self.token)
        self.assertEqual(order.subtotal, 200.0)
        self.assertEqual(order.tax_amount, 36.0)          # 18% default
        self.assertEqual(order.total_amount, 236.0)
        self.assertEqual(product_service.get_product(self.product.product_id).stock, 3)
        self.assertEqual(len(order_service.get_items(order.order_id)), 1)

    def test_cannot_order_more_than_stock(self):
        with self.assertRaises(OrderError):
            order_service.place_order(self.user.customer_id, {self.product.product_id: 6}, self.token)
        self.assertEqual(product_service.get_product(self.product.product_id).stock, 5)
        self.assertEqual(read_rows("orders"), [])

    def test_duplicate_submission_creates_one_order(self):
        cart = {self.product.product_id: 1}
        first = order_service.place_order(self.user.customer_id, cart, self.token)
        second = order_service.place_order(self.user.customer_id, cart, self.token)
        self.assertEqual(first.order_id, second.order_id)
        self.assertEqual(len(read_rows("orders")), 1)
        self.assertEqual(product_service.get_product(self.product.product_id).stock, 4)

    def test_last_unit_cannot_be_sold_twice(self):
        other = self.make_customer("b@example.com", "9876543211", "Bela Shah")
        cart = {self.product.product_id: 5}
        order_service.place_order(self.user.customer_id, cart, "b" * 32)
        with self.assertRaises(OrderError):
            order_service.place_order(other.customer_id, cart, "c" * 32)

    def test_cancel_restores_stock_once(self):
        order = order_service.place_order(self.user.customer_id, {self.product.product_id: 2}, self.token)
        order_service.change_status(order.order_id, "Cancelled", self.user)
        self.assertEqual(product_service.get_product(self.product.product_id).stock, 5)
        with self.assertRaises(OrderError):                    # cannot cancel twice
            order_service.change_status(order.order_id, "Cancelled", self.user)
        self.assertEqual(product_service.get_product(self.product.product_id).stock, 5)

    def test_customer_cannot_cancel_shipped_order(self):
        order = order_service.place_order(self.user.customer_id, {self.product.product_id: 1}, self.token)
        rows = read_rows("orders")
        rows[0]["status"] = "Shipped"
        write_rows("orders", rows)
        with self.assertRaises(OrderError):
            order_service.change_status(order.order_id, "Cancelled", self.user)

    def test_cart_validates_stock(self):
        session = FakeSession()
        cart_service.add_item(session, self.product.product_id, 5)
        with self.assertRaises(cart_service.CartError):
            cart_service.add_item(session, self.product.product_id, 1)


class WebFlowTests(TempDataTestCase):
    def setUp(self):
        super().setUp()
        self.product = self.make_product(price=250.0, stock=3)
        self.make_customer()
        self.make_customer("b@example.com", "9876543211", "Bela Shah")

    def test_full_customer_journey(self):
        self.assertEqual(self.login().status_code, 302)
        pid = self.product.product_id
        self.client.post(f"/cart/add/{pid}/", {"quantity": 2})
        page = self.client.get("/checkout/")
        self.assertContains(page, "Place demo order")
        token = self.client.session["checkout_token"]
        resp = self.client.post("/checkout/", {"token": token})
        self.assertEqual(resp.status_code, 302)
        order_id = read_rows("orders")[0]["order_id"]
        self.assertContains(self.client.get(f"/orders/{order_id}/"), order_id)
        self.assertEqual(product_service.get_product(pid).stock, 1)

    def test_other_customer_cannot_see_order(self):
        self.login()
        self.client.post(f"/cart/add/{self.product.product_id}/", {"quantity": 1})
        self.client.get("/checkout/")
        self.client.post("/checkout/", {"token": self.client.session["checkout_token"]})
        order_id = read_rows("orders")[0]["order_id"]
        self.client.post("/logout/")
        self.login("b@example.com")
        self.assertEqual(self.client.get(f"/orders/{order_id}/").status_code, 404)
        self.assertEqual(self.client.post(f"/orders/{order_id}/cancel/").status_code, 404)
        self.assertEqual(read_rows("orders")[0]["status"], "Pending")      # unchanged

    def test_customer_cannot_open_admin_pages(self):
        self.login()
        self.assertEqual(self.client.get("/manage/").status_code, 403)
        self.client.post("/logout/")
        self.assertEqual(self.client.get("/manage/").status_code, 302)     # anonymous -> login

    def test_wrong_password_and_lockout(self):
        for _ in range(5):
            self.login(password="Wrong1234")
        resp = self.login(password="Passw0rd1")                              # now locked
        self.assertContains(resp, "Too many failed attempts")

    def test_passwords_are_hashed(self):
        text = (self.tmp / "customers.csv").read_text()
        self.assertNotIn("Passw0rd1", text)
        self.assertIn("pbkdf2_sha256$", text)

    def test_csrf_is_enforced(self):
        from django.test import Client
        strict = Client(enforce_csrf_checks=True)
        self.assertEqual(strict.post("/login/", {"email": "a@example.com", "password": "x"}).status_code, 403)
