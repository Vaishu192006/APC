# ShopLedger: E-Commerce Management & Sales Analytics System

A BTech college project built with **Python, Django, CSV files, Pandas, NumPy, Matplotlib and Scikit-learn**.
No SQL database is used: all business data lives in the `data/` folder as CSV files.

---------------------------------------------------------------------------
## 1. Quick start (5 steps)

Requirements: **Python 3.10 or newer** and an internet connection in the browser
(Bootstrap and fonts load from a CDN; the site still works without them, just unstyled).

```bash
# 1. Open this folder in VS Code, then open the terminal (Ctrl + `)

# 2. Create and activate a virtual environment
python -m venv venv
venv\Scripts\activate            # Windows
source venv/bin/activate         # Linux / macOS

# 3. Install the packages
pip install -r requirements.txt

# 4. (Optional) Re-create fresh sample data with up-to-date dates
python manage.py init_data --reset

# 5. Start the server
python manage.py runserver
```

Open **http://127.0.0.1:8000/** in your browser.
There is **no `migrate` step**: Django's database is switched off on purpose.

### Demo accounts

| Role     | Email                | Password       |
|----------|----------------------|----------------|
| Admin    | admin@shop.com       | Admin@123      |
| Customer | customer@shop.com    | Customer@123   |

Other sample customers (aarav@example.com, sneha@example.com, ...) all use `Customer@123`.
**Change these passwords before showing the project outside your college.**

### Make another admin
Register a normal account on the website, then open `data/customers.csv` (close it in Excel afterwards)
and change that row's `role` from `customer` to `admin`.

---------------------------------------------------------------------------
## 2. Project structure

```
ecommerce_project/
├── manage.py, requirements.txt, .gitignore, README.md
├── config/                  settings.py (tax rate, CSV folder, sessions), urls.py
├── shop/
│   ├── models/              OOP classes: BaseEntity, Product, User/Customer/Admin, Order, OrderItem
│   ├── storage/             schemas.py (CSV columns) and csv_store.py (safe read/write/locks)
│   ├── services/            validators (regex), auth, products, cart, orders,
│   │                        analytics (Pandas/NumPy/Matplotlib), recommender (Scikit-learn)
│   ├── views/               auth_views, customer_views, admin_views, helpers
│   ├── templates/           base layout, customer pages, admin pages, error pages
│   ├── static/shop/         style.css, main.js, placeholder.svg
│   ├── management/commands/ init_data.py (sample data)
│   ├── forms.py, urls.py, decorators.py, middleware.py, context_processors.py
├── data/                    products.csv, categories.csv, customers.csv, orders.csv, order_items.csv, reviews.csv
└── tests/                   automated tests
```

Request flow: **Browser → urls.py → view → service → csv_store → CSV file**.
Views never touch CSV files directly; only `csv_store.py` does.

---------------------------------------------------------------------------
## 3. CSV files (columns)

| File | Columns |
|---|---|
| categories.csv | category_id, name, description |
| products.csv | product_id, name, description, category_id, price, stock, image_path, created_at, is_active |
| customers.csv | customer_id, name, email, phone, password_hash, role, address, created_at |
| orders.csv | order_id, customer_id, order_date, subtotal, tax_rate, tax_amount, total_amount, status, idempotency_token |
| order_items.csv | item_id, order_id, product_id, product_name, unit_price, quantity, line_total |
| reviews.csv | review_id, product_id, customer_id, rating, comment, created_at |

The cart is kept in the session (not a CSV file) until the order is placed.
Order items store a **snapshot** of the product name and price, so old orders never change when a product is edited.

---------------------------------------------------------------------------
## 4. Features

**Customer**: register, log in/out, search, filter by category and price, sort, product details with
reviews, cart (add, +/-, remove), demo checkout, order confirmation, order history, cancel own order
(before it is shipped), personal dashboard, product recommendations.

**Admin**: dashboard with low-stock warnings, add/edit/delete products, manage categories, view customers,
search/filter orders, update order status, full sales analytics with date-range filter and charts.

**Business rules**
* Tax: `TAX_RATE = 0.18` (18% GST) in `config/settings.py`, also changeable with the `SHOP_TAX_RATE` environment variable.
* Revenue counts only **Confirmed, Shipped, Delivered** orders (tax included). Pending and Cancelled are excluded everywhere.
* Status flow: Pending → Confirmed → Shipped → Delivered; Cancelled is possible until Delivered.
* Customers can cancel only **Pending/Confirmed** orders. Cancelling returns stock exactly once.
* Products already used in past orders are **archived** instead of deleted (so old orders stay valid).
* Low stock = 5 units or fewer (`LOW_STOCK_THRESHOLD`).

---------------------------------------------------------------------------
## 5. Machine learning: product recommendations

File: `shop/services/recommender.py`

1. Each product becomes one text: name + category (x3) + description.
2. **TF-IDF** (`TfidfVectorizer`) converts texts to number vectors (rare, meaningful words weigh more).
3. **Cosine similarity** measures how similar two vectors are (0 to 1).
4. *Product page*: show the products most similar to the one being viewed.
5. *Home / dashboard*: average the vectors of products the customer bought (a "taste profile") and recommend the closest products not yet bought.
6. *Fallback*: new customers get best-sellers, then the newest products. Out-of-stock items are never recommended.

**Limitations**: uses text only (no "customers who bought X also bought Y"), depends on description quality,
recomputed on each request (fine for small catalogues), needs at least 2 products. Sales forecasting is not included.

---------------------------------------------------------------------------
## 6. Security design and trade-offs

| Topic | What is done | Limitation |
|---|---|---|
| Passwords | PBKDF2 hashes (Django hashers); never stored in plain text | |
| Login | Email + password; 5 failed attempts lock that email for 5 minutes | Counter is in memory and resets on restart |
| Sessions | **Signed cookies** (no database needed), HttpOnly, SameSite=Lax, 2-hour life | Signed, not encrypted (stores only IDs and the cart); cannot be revoked on the server |
| CSRF | Enabled on every POST form | |
| Authorization | `@login_required_csv`, `@customer_required`, `@admin_required`; customers get 404 for other people's orders | |
| Input | Server-side validation with `re` (validators.py); templates auto-escape HTML; text cannot start with `= + - @` (spreadsheet formula injection) | |
| File paths | Only names listed in `SCHEMAS` can be opened (no path traversal) | |
| Secrets | `SECRET_KEY` from the `DJANGO_SECRET_KEY` variable or a generated, git-ignored `.secret_key` file | |
| Duplicate orders | Each checkout form has a one-time token stored with the order; double clicks return the same order | |

### Simultaneous orders and CSV limits
* `csv_store.transaction()` takes **file locks** on all files needed (in sorted order to avoid deadlocks).
* Inside the lock, `place_order()` **re-reads stock**, so two buyers cannot both get the last item.
* Files are written to a **temporary file and then replaced atomically**, so a crash never leaves a half-written CSV.
* **Remaining limits**: this is not a real database transaction. If the computer loses power between the three file writes
  (items, orders, products), the files can disagree. Locks work on one machine only. CSV is slow for large data.
  For production, use a real database.

---------------------------------------------------------------------------
## 7. Python syllabus coverage (where to point in your viva)

| Concept | Where |
|---|---|
| Variables, types, operators, I/O | everywhere; `init_data.py` prints to console |
| Conditionals and loops | `order_service.place_order`, `cart_service.build_cart` |
| Strings and methods | `validators.py` (`split`, `join`, `strip`, `lower`, f-strings) |
| List, tuple, set, dict | `schemas.py`: tuples (SCHEMAS), sets (STATUS_TRANSITIONS), dicts; `recommender.py` |
| Functions, lambda | `product_service.SORTS` (lambda sort keys), many small functions |
| OOP: classes, encapsulation, inheritance, polymorphism | `models/`: `BaseEntity` → `Product`; `User` → `Customer` / `Admin`, private `_password_hash`, overridden `is_admin` and `home_url_name` |
| Modules and packages | `shop/models`, `shop/services`, `shop/storage` |
| CSV and directory operations | `storage/csv_store.py` (`csv`, `os`, `pathlib`, `tempfile`) |
| try / except / finally | `csv_store`, `analytics_service.load_frame`, views (`ExitStack`/context managers act as `finally`) |
| Regular expressions | `services/validators.py` |
| NumPy | `analytics_service` (`np.mean`, `np.convolve` moving average), `recommender` (`np.argsort`, `np.asarray`) |
| Pandas | `analytics_service.build_report` (read_csv, filter, groupby, merge-style map, reindex) |
| Matplotlib | `analytics_service.chart_*` (line, bar and horizontal bar charts) |
| Scikit-learn | `recommender.py` |
| Django structure | `config/`, `shop/urls.py`, views, templates, forms, middleware, management command |

---------------------------------------------------------------------------
## 8. Running the tests

```bash
python manage.py test tests
```
24 tests cover CSV handling, validators, order totals, stock reduction, cancellation, duplicate
submission, access control, login lockout, password hashing and CSRF. Tests use a temporary folder,
so your real `data/` files are never changed.

## 9. Manual testing checklist

- [ ] Home page loads with recommendations and new arrivals
- [ ] Search "book", filter by category, price range 500-800, sort by price
- [ ] Out-of-stock product (Mixer Grinder) shows the label and has no Add button
- [ ] Register a new customer; wrong phone/email/password format shows errors
- [ ] Log in as customer; add items; use +/-; remove an item; try to exceed stock (error message)
- [ ] Checkout shows subtotal, GST 18%, total and the demo banner; placing the order shows the confirmation
- [ ] Stock of the product dropped by the quantity ordered (check `data/products.csv`)
- [ ] Order history shows the order; cancel it; stock returns
- [ ] Log in as a different customer and open the first customer's order URL: you get "page not found"
- [ ] Log in as customer and open `/manage/`: access denied page
- [ ] Log in as admin: dashboard shows low-stock warnings and recent orders
- [ ] Add a product with a negative price: rejected
- [ ] Edit a product, delete a never-sold product (removed), delete a sold product (archived)
- [ ] Change an order's status Pending → Confirmed → Shipped; an illegal move is refused
- [ ] Analytics page: KPIs, four charts, date filter, best/least-selling tables
- [ ] Remove a product image path / use a broken URL: the placeholder appears

## 10. Troubleshooting

| Problem | Fix |
|---|---|
| `No module named django` | Activate the virtual environment, then `pip install -r requirements.txt` |
| Page has no styling | Browser is offline (Bootstrap loads from a CDN) |
| "Cannot update ... file is open in Excel" | Close the CSV in Excel and retry |
| Data looks old or broken | `python manage.py init_data --reset` (this **deletes** all current data) |
| Port already in use | `python manage.py runserver 8080` |

## 11. Possible future improvements
Product image upload, real payment gateway, email notifications, sales forecasting with `LinearRegression`,
and moving from CSV to a real database (the `services/` layer is the only code that would change).
