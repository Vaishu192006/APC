"""Root URL configuration: everything is handled by the 'shop' app."""
from django.urls import include, path

urlpatterns = [
    path("", include("shop.urls")),
]
