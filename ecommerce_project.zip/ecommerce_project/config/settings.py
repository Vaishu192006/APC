"""
Django settings for the E-Commerce Management & Sales Analytics System.

IMPORTANT DESIGN NOTE
---------------------
All business data is stored in CSV files (see /data). Therefore:
  * DATABASES is empty - no SQL database is used anywhere.
  * django.contrib.auth is NOT installed (it needs a database).
    Authentication is implemented in shop/services/auth_service.py.
  * Sessions use SIGNED COOKIES (no database table needed).
"""
import os
from pathlib import Path

from django.core.management.utils import get_random_secret_key

BASE_DIR = Path(__file__).resolve().parent.parent


def _load_secret_key():
    """Read SECRET_KEY from the environment, else from a local git-ignored file.

    If neither exists, a random key is generated once and saved, so no secret
    is ever hardcoded in the source code.
    """
    key = os.environ.get("DJANGO_SECRET_KEY")
    if key:
        return key
    key_file = BASE_DIR / ".secret_key"
    if key_file.exists():
        return key_file.read_text(encoding="utf-8").strip()
    key = get_random_secret_key()
    try:
        key_file.write_text(key, encoding="utf-8")
    except OSError:
        pass  # read-only folder: key lives only for this run
    return key


SECRET_KEY = _load_secret_key()
DEBUG = os.environ.get("DJANGO_DEBUG", "1") == "1"
ALLOWED_HOSTS = os.environ.get("DJANGO_ALLOWED_HOSTS", "localhost,127.0.0.1,testserver").split(",")

INSTALLED_APPS = [
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "shop",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "shop.middleware.CurrentUserMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "config.urls"
WSGI_APPLICATION = "config.wsgi.application"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.messages.context_processors.messages",
                "shop.context_processors.shop_globals",
            ],
        },
    },
]

# ---- No SQL database (business data lives in CSV files) -------------------
DATABASES = {}

# ---- Sessions: signed cookies, no database needed -------------------------
SESSION_ENGINE = "django.contrib.sessions.backends.signed_cookies"
SESSION_COOKIE_AGE = 60 * 60 * 2          # 2 hours
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = "Lax"
CSRF_COOKIE_SAMESITE = "Lax"
MESSAGE_STORAGE = "django.contrib.messages.storage.cookie.CookieStorage"

if not DEBUG:  # extra hardening for real deployments
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SECURE_SSL_REDIRECT = os.environ.get("DJANGO_SSL_REDIRECT", "0") == "1"
    SECURE_CONTENT_TYPE_NOSNIFF = True

# ---- Internationalisation -------------------------------------------------
LANGUAGE_CODE = "en-us"
TIME_ZONE = "Asia/Kolkata"
USE_I18N = False
USE_TZ = False   # naive local datetimes are simpler to store in CSV

STATIC_URL = "static/"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# ---- Application settings (shop) -----------------------------------------
DATA_DIR = BASE_DIR / "data"                              # where the CSV files live
TAX_RATE = float(os.environ.get("SHOP_TAX_RATE", "0.18"))  # 18% GST - change here
TAX_LABEL = "GST"
CURRENCY_SYMBOL = "₹"
LOW_STOCK_THRESHOLD = 5          # stock <= this value shows a low-stock warning
MAX_QTY_PER_ITEM = 10            # max units of one product per cart line
