"""
python manage.py init_data            -> create CSV files + sample data (only if empty)
python manage.py init_data --reset    -> wipe ALL data and recreate the samples

Creates: 5 categories, 20 products, 1 admin, 8 customers and ~80 sample orders
spread over the last 90 days (so the dashboard and recommender have data).
"""
import random
from datetime import datetime, timedelta

from django.conf import settings
from django.contrib.auth.hashers import make_password
from django.core.management.base import BaseCommand

from shop.services.cart_service import calculate_totals
from shop.storage.csv_store import ensure_all, read_rows, transaction, write_rows
from shop.storage.schemas import SCHEMAS

ADMIN_EMAIL, ADMIN_PASSWORD = "admin@shop.com", "Admin@123"
CUSTOMER_PASSWORD = "Customer@123"

CATEGORIES = [
    ("C001", "Electronics", "Phones, audio and gadgets"),
    ("C002", "Fashion", "Clothing, shoes and accessories"),
    ("C003", "Home & Kitchen", "Appliances and everyday home items"),
    ("C004", "Books", "Textbooks, programming and fiction"),
    ("C005", "Sports & Fitness", "Equipment for training and outdoor play"),
]

# (id, name, description, category, price, stock)
PRODUCTS = [
    ("P001", "Wireless Bluetooth Headphones", "Over-ear wireless headphones with deep bass, noise isolation and 30 hour battery for music and calls", "C001", 2499, 25),
    ("P002", "Smartphone 128GB", "Android smartphone with 128GB storage, AMOLED display, fast charging and dual camera", "C001", 15999, 12),
    ("P003", "Portable Power Bank 20000mAh", "Fast charging power bank with two USB ports to charge phone and gadgets on the go", "C001", 1799, 4),
    ("P004", "Smart Fitness Watch", "Smartwatch with heart rate monitor, step counter, sleep tracking and water resistance", "C001", 3299, 18),
    ("P005", "Cotton Casual T-Shirt", "Soft breathable cotton t-shirt in a relaxed fit for everyday casual wear", "C002", 599, 60),
    ("P006", "Slim Fit Denim Jeans", "Stretch denim jeans with slim fit, durable stitching and classic five pocket design", "C002", 1499, 35),
    ("P007", "Running Shoes", "Lightweight running shoes with cushioned sole and breathable mesh for daily training", "C002", 2799, 3),
    ("P008", "Leather Wallet", "Genuine leather wallet with card slots, coin pocket and slim travel friendly design", "C002", 799, 40),
    ("P009", "Non-Stick Cookware Set", "Five piece non-stick cookware set with cool touch handles for everyday kitchen cooking", "C003", 2199, 15),
    ("P010", "Electric Kettle 1.5L", "Stainless steel electric kettle with auto shut off to boil water for tea and coffee quickly", "C003", 899, 30),
    ("P011", "Mixer Grinder 750W", "Powerful kitchen mixer grinder with three jars for grinding, blending and chutney making", "C003", 3499, 0),
    ("P012", "LED Desk Lamp", "Adjustable LED desk lamp with touch dimmer and USB charging port for study and reading", "C003", 1099, 22),
    ("P013", "Python Programming for Beginners", "Beginner friendly programming book covering python basics, data structures, functions and file handling", "C004", 549, 50),
    ("P014", "Data Science with Pandas and NumPy", "Practical programming guide to data analysis, pandas dataframes, numpy arrays and matplotlib charts", "C004", 749, 28),
    ("P015", "Machine Learning with Scikit-learn", "Introduction to machine learning with python, scikit-learn models, classification and recommendation systems", "C004", 899, 20),
    ("P016", "Mystery Novel Collection", "Fiction box set of three gripping mystery novels with detectives, suspense and twists", "C004", 699, 5),
    ("P017", "Yoga Mat Anti-Slip", "Thick anti-slip yoga mat for home workouts, stretching, pilates and fitness training", "C005", 699, 45),
    ("P018", "Adjustable Dumbbell Set", "Adjustable weight dumbbell set for home strength training and fitness workouts", "C005", 3999, 10),
    ("P019", "Football Size 5", "Durable stitched football for outdoor sports, practice matches and training", "C005", 849, 33),
    ("P020", "Insulated Sports Bottle", "Stainless steel insulated bottle that keeps water cold for gym, running and outdoor sports", "C005", 499, 2),
]

CUSTOMERS = [
    ("U002", "Demo Customer", "customer@shop.com", "9876500002"),
    ("U003", "Aarav Patil", "aarav@example.com", "9876500003"),
    ("U004", "Sneha Kulkarni", "sneha@example.com", "9876500004"),
    ("U005", "Rohan Deshmukh", "rohan@example.com", "9876500005"),
    ("U006", "Priya Jadhav", "priya@example.com", "9876500006"),
    ("U007", "Kunal Shinde", "kunal@example.com", "9876500007"),
    ("U008", "Neha Pawar", "neha@example.com", "9876500008"),
    ("U009", "Omkar More", "omkar@example.com", "9876500009"),
]


class Command(BaseCommand):
    help = "Create CSV files with realistic sample data, an admin and demo customers."

    def add_arguments(self, parser):
        parser.add_argument("--reset", action="store_true", help="Delete all existing data first")

    def handle(self, *args, **options):
        ensure_all()
        names = list(SCHEMAS)
        with transaction(*names):
            if options["reset"]:
                for name in names:
                    write_rows(name, [])
            elif any(read_rows(n) for n in ("products", "customers", "orders")):
                self.stdout.write(self.style.WARNING(
                    "Data already exists. Nothing changed. Use --reset to start over."))
                return
            self._create(random.Random(42))
        self.stdout.write(self.style.SUCCESS("Sample data created."))
        self.stdout.write(f"  Admin    : {ADMIN_EMAIL} / {ADMIN_PASSWORD}")
        self.stdout.write(f"  Customer : customer@shop.com / {CUSTOMER_PASSWORD}")

    # ----------------------------------------------------------------------
    def _create(self, rng):
        now = datetime.now().replace(microsecond=0)
        write_rows("categories", [dict(zip(SCHEMAS["categories"], c)) for c in CATEGORIES])

        products = []
        for i, (pid, name, desc, cat, price, stock) in enumerate(PRODUCTS):
            products.append({
                "product_id": pid, "name": name, "description": desc, "category_id": cat,
                "price": f"{price:.2f}", "stock": str(stock), "image_path": "",
                "created_at": (now - timedelta(days=100 - i * 3)).strftime("%Y-%m-%d %H:%M:%S"),
                "is_active": "1"})
        write_rows("products", products)

        admin_hash = make_password(ADMIN_PASSWORD)
        customer_hash = make_password(CUSTOMER_PASSWORD)      # same hash reused (faster)
        users = [{"customer_id": "U001", "name": "Store Admin", "email": ADMIN_EMAIL,
                  "phone": "9876500001", "password_hash": admin_hash, "role": "admin",
                  "address": "Head Office", "created_at": (now - timedelta(days=120)).strftime("%Y-%m-%d %H:%M:%S")}]
        for cid, name, email, phone in CUSTOMERS:
            users.append({"customer_id": cid, "name": name, "email": email, "phone": phone,
                          "password_hash": customer_hash, "role": "customer",
                          "address": "Kolhapur, Maharashtra",
                          "created_at": (now - timedelta(days=rng.randint(60, 110))).strftime("%Y-%m-%d %H:%M:%S")})
        write_rows("customers", users)

        self._orders(rng, now, products)
        self._reviews(rng, now)

    def _orders(self, rng, now, products):
        by_cat = {}
        for p in products:
            by_cat.setdefault(p["category_id"], []).append(p)
        favourite = {cid: rng.choice(list(by_cat)) for cid, *_ in CUSTOMERS}   # each has a taste

        orders, items, n_items = [], [], 0
        for n in range(80):
            cid = rng.choice(CUSTOMERS)[0]
            when = now - timedelta(days=rng.randint(0, 89), hours=rng.randint(0, 23), minutes=rng.randint(0, 59))
            age = (now - when).days
            if age > 14:
                status = rng.choices(["Delivered", "Cancelled", "Shipped"], [80, 15, 5])[0]
            else:
                status = rng.choices(["Pending", "Confirmed", "Shipped", "Delivered", "Cancelled"],
                                     [25, 25, 20, 20, 10])[0]
            order_id = f"ORD-{when:%Y%m%d}-{rng.randrange(16**6):06X}"
            chosen = set()
            for _ in range(rng.randint(1, 3)):
                pool = by_cat[favourite[cid]] if rng.random() < 0.65 else rng.choice(list(by_cat.values()))
                chosen.add(rng.choice(pool)["product_id"])
            subtotal = 0.0
            for pid in sorted(chosen):
                p = next(x for x in products if x["product_id"] == pid)
                qty, price = rng.randint(1, 3), float(p["price"])
                n_items += 1
                items.append({"item_id": f"OI{n_items:04d}", "order_id": order_id, "product_id": pid,
                              "product_name": p["name"], "unit_price": f"{price:.2f}",
                              "quantity": str(qty), "line_total": f"{price * qty:.2f}"})
                subtotal += price * qty
            subtotal, tax, total = calculate_totals(subtotal)
            orders.append({"order_id": order_id, "customer_id": cid,
                           "order_date": when.strftime("%Y-%m-%d %H:%M:%S"),
                           "subtotal": f"{subtotal:.2f}", "tax_rate": str(settings.TAX_RATE),
                           "tax_amount": f"{tax:.2f}", "total_amount": f"{total:.2f}",
                           "status": status, "idempotency_token": f"{n:032x}"})
        write_rows("orders", sorted(orders, key=lambda o: o["order_date"]))
        write_rows("order_items", items)

    def _reviews(self, rng, now):
        comments = ["Great value for money.", "Works as described.", "Good quality, would buy again.",
                    "Delivery was quick.", "Decent, but could be better."]
        rows = []
        for n, (pid, *_rest) in enumerate(PRODUCTS[:12], start=1):
            cid = rng.choice(CUSTOMERS)[0]
            rows.append({"review_id": f"R{n:03d}", "product_id": pid, "customer_id": cid,
                         "rating": str(rng.randint(3, 5)), "comment": rng.choice(comments),
                         "created_at": (now - timedelta(days=rng.randint(1, 60))).strftime("%Y-%m-%d %H:%M:%S")})
        write_rows("reviews", rows)
