from django import template
from django.conf import settings

register = template.Library()


@register.filter
def money(value):
    """Format a number as currency, e.g. 1234.5 -> ₹1,234.50"""
    try:
        return f"{settings.CURRENCY_SYMBOL}{float(value):,.2f}"
    except (TypeError, ValueError):
        return f"{settings.CURRENCY_SYMBOL}0.00"


@register.filter
def status_class(status):
    """Bootstrap colour for an order status."""
    return {
        "Pending": "warning text-dark",
        "Confirmed": "info text-dark",
        "Shipped": "primary",
        "Delivered": "success",
        "Cancelled": "danger",
    }.get(status, "secondary")


@register.filter
def stars(rating):
    try:
        n = max(0, min(5, int(round(float(rating)))))
    except (TypeError, ValueError):
        n = 0
    return "★" * n + "☆" * (5 - n)
