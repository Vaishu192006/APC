"""
User hierarchy demonstrating inheritance, encapsulation and polymorphism.

    User  (base class)
     ├── Customer
     └── Admin

The password hash is stored in a "private" attribute (_password_hash) and is
only reachable through methods.
"""
from django.contrib.auth.hashers import check_password, make_password

from ..storage.schemas import SCHEMAS
from .base import BaseEntity

PUBLIC_FIELDS = tuple(f for f in SCHEMAS["customers"] if f != "password_hash")


class User(BaseEntity):
    FIELDS = PUBLIC_FIELDS

    def __init__(self, **kwargs):
        self._password_hash = kwargs.pop("password_hash", "")     # encapsulated
        super().__init__(**kwargs)

    # ---- encapsulated password handling ----
    def check_password(self, raw_password):
        return bool(self._password_hash) and check_password(raw_password, self._password_hash)

    def set_password(self, raw_password):
        self._password_hash = make_password(raw_password)

    def to_row(self):
        row = super().to_row()
        row["password_hash"] = self._password_hash
        return row

    # ---- polymorphic behaviour (overridden in child classes) ----
    @property
    def is_admin(self):
        return False

    @property
    def home_url_name(self):
        return "shop:home"

    def role_label(self):
        return "User"

    @property
    def first_name(self):
        return self.name.split()[0] if self.name else ""


class Customer(User):
    @property
    def home_url_name(self):
        return "shop:customer_dashboard"

    def role_label(self):
        return "Customer"


class Admin(User):
    @property
    def is_admin(self):
        return True

    @property
    def home_url_name(self):
        return "shop:admin_dashboard"

    def role_label(self):
        return "Administrator"


def build_user(row):
    """Factory: returns an Admin or Customer object depending on the role."""
    cls = Admin if row.get("role") == "admin" else Customer
    return cls(**row)
