from ..storage.schemas import CUSTOMER_CANCELLABLE, REVENUE_STATUSES, SCHEMAS
from .base import BaseEntity, to_float, to_int


class OrderItem(BaseEntity):
    FIELDS = SCHEMAS["order_items"]

    @classmethod
    def from_row(cls, row):
        data = dict(row)
        data["unit_price"] = to_float(data.get("unit_price"))
        data["quantity"] = to_int(data.get("quantity"))
        data["line_total"] = to_float(data.get("line_total"))
        return cls(**data)


class Order(BaseEntity):
    FIELDS = SCHEMAS["orders"]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.customer_name = kwargs.get("customer_name", "")   # filled by services
        self.items = []

    @classmethod
    def from_row(cls, row):
        data = dict(row)
        for col in ("subtotal", "tax_rate", "tax_amount", "total_amount"):
            data[col] = to_float(data.get(col))
        return cls(**data)

    @property
    def counts_as_revenue(self):
        return self.status in REVENUE_STATUSES

    @property
    def customer_can_cancel(self):
        return self.status in CUSTOMER_CANCELLABLE

    @property
    def tax_percent(self):
        return round(self.tax_rate * 100, 2)

    @property
    def item_count(self):
        return sum(item.quantity for item in self.items)
