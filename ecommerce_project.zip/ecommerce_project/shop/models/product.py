from django.conf import settings
from django.templatetags.static import static

from ..storage.schemas import SCHEMAS
from .base import BaseEntity, to_float, to_int


class Product(BaseEntity):
    FIELDS = SCHEMAS["products"]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.category_name = kwargs.get("category_name", "")   # filled by services

    @classmethod
    def from_row(cls, row):
        data = dict(row)
        data["price"] = to_float(data.get("price"))
        data["stock"] = to_int(data.get("stock"))
        data["is_active"] = data.get("is_active", "1") == "1"
        return cls(**data)

    def to_row(self):
        row = super().to_row()
        row["price"] = f"{self.price:.2f}"
        row["stock"] = str(int(self.stock))
        row["is_active"] = "1" if self.is_active else "0"
        return row

    # ---- behaviour (methods + properties = encapsulation) ----
    @property
    def in_stock(self):
        return self.stock > 0

    @property
    def is_low_stock(self):
        return 0 < self.stock <= settings.LOW_STOCK_THRESHOLD

    @property
    def stock_label(self):
        if self.stock <= 0:
            return "Out of stock"
        if self.is_low_stock:
            return f"Only {self.stock} left"
        return "In stock"

    @property
    def image_url(self):
        """URL for the image; falls back to a local placeholder."""
        path = (self.image_path or "").strip()
        if path.startswith(("http://", "https://")):
            return path
        if path:
            return static(path)
        return static("shop/img/placeholder.svg")

    def can_fulfil(self, quantity):
        return self.is_active and 1 <= quantity <= self.stock

    def __str__(self):
        return self.name
