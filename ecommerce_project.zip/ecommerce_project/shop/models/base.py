"""Base class for all entities (inheritance): converts CSV rows <-> objects."""


def to_float(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def to_int(value, default=0):
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


class BaseEntity:
    """Parent class. Child classes only list their FIELDS."""

    FIELDS = ()

    def __init__(self, **kwargs):
        for field in self.FIELDS:
            setattr(self, field, kwargs.get(field, ""))

    @classmethod
    def from_row(cls, row):
        """Build an object from a CSV row (a dictionary)."""
        return cls(**row)

    def to_row(self):
        """Convert the object back to a CSV row (all values as text)."""
        return {field: str(getattr(self, field)) for field in self.FIELDS}

    def __repr__(self):
        first = self.FIELDS[0]
        return f"<{self.__class__.__name__} {getattr(self, first)}>"
