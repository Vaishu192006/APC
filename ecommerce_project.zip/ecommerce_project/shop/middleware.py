"""Attaches `request.current_user` (an Admin/Customer object or None)."""
from .services import auth_service


class CurrentUserMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        request.current_user = None
        customer_id = request.session.get("customer_id")
        if customer_id:
            user = auth_service.get_user(customer_id)
            if user is None:                      # account was deleted
                request.session.flush()
            else:
                request.current_user = user
        return self.get_response(request)
