"""
schemas.py - the single source of truth for every CSV file.

Defines column names, ID prefixes, order statuses and the status rules.
All other modules import these names instead of hard-coding strings.
"""
from pathlib import Path

from django.conf import settings

# File name -> ordered tuple of column names
SCHEMAS = {
    "categories": ("category_id", "name", "description"),
    "products": (
        "product_id", "name", "description", "category_id",
        "price", "stock", "image_path", "created_at", "is_active",
    ),
    "customers": (
        "customer_id", "name", "email", "phone",
        "password_hash", "role", "address", "created_at",
    ),
    "orders": (
        "order_id", "customer_id", "order_date", "subtotal",
        "tax_rate", "tax_amount", "total_amount", "status",
        "idempotency_token",
    ),
    "order_items": (
        "item_id", "order_id", "product_id", "product_name",
        "unit_price", "quantity", "line_total",
    ),
    "reviews": (
        "review_id", "product_id", "customer_id",
        "rating", "comment", "created_at",
    ),
}

# file -> (id column, prefix, number width) used to generate unique IDs
ID_PREFIX = {
    "categories": ("category_id", "C", 3),
    "products": ("product_id", "P", 3),
    "customers": ("customer_id", "U", 3),
    "order_items": ("item_id", "OI", 4),
    "reviews": ("review_id", "R", 3),
}

# Tuples are fixed and cannot be changed by accident
ORDER_STATUSES = ("Pending", "Confirmed", "Shipped", "Delivered", "Cancelled")

# Only these statuses count as real revenue (Pending and Cancelled do not)
REVENUE_STATUSES = ("Confirmed", "Shipped", "Delivered")

# Allowed status moves (dictionary of sets). Anything else is rejected.
STATUS_TRANSITIONS = {
    "Pending": {"Confirmed", "Cancelled"},
    "Confirmed": {"Shipped", "Cancelled"},
    "Shipped": {"Delivered", "Cancelled"},
    "Delivered": set(),
    "Cancelled": set(),
}

# A customer may cancel only while the order has not been shipped
CUSTOMER_CANCELLABLE = {"Pending", "Confirmed"}


def data_dir() -> Path:
    """Folder that holds the CSV files (read from settings at call time)."""
    return Path(settings.DATA_DIR)


def csv_path(name: str) -> Path:
    """Return the full path for a known CSV name, e.g. 'products'.

    Only names listed in SCHEMAS are accepted, so user input can never build
    an arbitrary file path (prevents path traversal).
    """
    if name not in SCHEMAS:
        raise ValueError(f"Unknown data file: {name!r}")
    return data_dir() / f"{name}.csv"
