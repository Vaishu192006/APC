"""
csv_store.py - reusable CSV helper functions (the ONLY module that writes CSV).

Safety features
  * ensure_file()  : creates missing / empty files with the correct header.
  * read_rows()    : skips malformed rows instead of crashing.
  * write_rows()   : writes to a temporary file, then atomically replaces the
                     original (os.replace) so a crash never leaves a half-file.
  * transaction()  : cross-process file locks so two requests cannot update the
                     same CSV at the same time (read-modify-write is protected).
  * next_id()      : generates unique IDs such as P001, U002.

Limitation: this is NOT a real database transaction. If the computer crashes
between two file writes, files can be out of sync. See README for details.
"""
import csv
import logging
import os
import re
import tempfile
import threading
from contextlib import ExitStack, contextmanager
from datetime import datetime

from filelock import FileLock, Timeout

from .schemas import ID_PREFIX, SCHEMAS, csv_path, data_dir

logger = logging.getLogger(__name__)


class CSVStorageError(Exception):
    """Raised when a CSV file cannot be read or written safely."""


# ---------------------------------------------------------------- locking ---
_LOCKS = {}
_REGISTRY_LOCK = threading.Lock()


def _lock_for(name):
    """Return (and cache) one FileLock object per CSV file."""
    data_dir().mkdir(parents=True, exist_ok=True)
    lock_path = str(csv_path(name)) + ".lock"
    with _REGISTRY_LOCK:
        if lock_path not in _LOCKS:
            _LOCKS[lock_path] = FileLock(lock_path, timeout=10)
        return _LOCKS[lock_path]


@contextmanager
def transaction(*names):
    """Lock one or more CSV files for a safe read-modify-write.

    Locks are always taken in sorted order, which prevents deadlocks when two
    requests need the same files. The lock is re-entrant (nesting is fine).

        with transaction("products", "orders"):
            rows = read_rows("products")
            ...
            write_rows("products", rows)
    """
    with ExitStack() as stack:
        for name in sorted(set(names)):
            try:
                stack.enter_context(_lock_for(name))
            except Timeout as exc:
                raise CSVStorageError(
                    "The data file is busy. Please try again in a moment."
                ) from exc
        yield


# ------------------------------------------------------------- file setup ---
def _write_atomic(name, rows):
    """Write rows to a temp file, then replace the real file in one step."""
    path = csv_path(name)
    columns = SCHEMAS[name]
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(dir=path.parent, prefix=f".{name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=columns, extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                writer.writerow({col: row.get(col, "") for col in columns})
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp_name, path)       # atomic on Windows, Linux and macOS
    except PermissionError as exc:
        _remove_quietly(tmp_name)
        raise CSVStorageError(
            f"Cannot update {path.name}. If it is open in Excel, close it and retry."
        ) from exc
    except Exception:
        _remove_quietly(tmp_name)
        raise


def _remove_quietly(path):
    try:
        os.remove(path)
    except OSError:
        pass


def ensure_file(name):
    """Create the CSV (header only) if it is missing or empty."""
    path = csv_path(name)
    if path.exists() and path.stat().st_size > 0:
        return
    with transaction(name):
        if not path.exists() or path.stat().st_size == 0:
            _write_atomic(name, [])


def ensure_all():
    """Make sure the data folder and every CSV file exist."""
    data_dir().mkdir(parents=True, exist_ok=True)
    for name in SCHEMAS:
        ensure_file(name)


# ----------------------------------------------------------- read / write ---
def read_rows(name):
    """Return all rows of a CSV as a list of dictionaries (all values are str).

    Malformed rows (wrong number of fields) are skipped and logged.
    A header with missing columns raises CSVStorageError.
    """
    ensure_file(name)
    path = csv_path(name)
    columns = SCHEMAS[name]
    rows = []
    try:
        with open(path, newline="", encoding="utf-8-sig") as fh:
            reader = csv.DictReader(fh)
            if reader.fieldnames is None:
                return []
            missing = [c for c in columns if c not in reader.fieldnames]
            if missing:
                raise CSVStorageError(
                    f"{path.name} is missing columns: {', '.join(missing)}"
                )
            for line_no, row in enumerate(reader, start=2):
                if None in row or any(v is None for v in row.values()):
                    logger.warning("Skipping malformed row %s in %s", line_no, path.name)
                    continue
                rows.append({c: (row.get(c) or "").strip() for c in columns})
    except (OSError, csv.Error, UnicodeDecodeError) as exc:
        raise CSVStorageError(f"Could not read {path.name}: {exc}") from exc
    return rows


def write_rows(name, rows):
    """Replace the whole CSV with `rows`. Call inside `transaction(name)`."""
    try:
        _write_atomic(name, rows)
    except OSError as exc:
        raise CSVStorageError(f"Could not write {name}.csv: {exc}") from exc


def append_row(name, row):
    """Safely add one row (locked read-modify-write)."""
    with transaction(name):
        rows = read_rows(name)
        rows.append(row)
        write_rows(name, rows)


# ---------------------------------------------------------------- helpers ---
def next_id(name, rows=None):
    """Generate the next unique ID for a file, e.g. P007 -> P008."""
    id_col, prefix, width = ID_PREFIX[name]
    rows = rows if rows is not None else read_rows(name)
    pattern = re.compile(rf"^{re.escape(prefix)}(\d+)$")
    numbers = []
    for row in rows:
        match = pattern.match(row[id_col])
        if match:
            numbers.append(int(match.group(1)))
    return f"{prefix}{max(numbers, default=0) + 1:0{width}d}"


def find_all(name, **criteria):
    """Return rows where every column equals the given value."""
    return [r for r in read_rows(name) if all(r.get(k) == v for k, v in criteria.items())]


def find_one(name, **criteria):
    """Return the first matching row, or None."""
    matches = find_all(name, **criteria)
    return matches[0] if matches else None


def now_iso():
    """Current date-time as a text value for CSV storage."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def to_float(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def to_int(value, default=0):
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default
