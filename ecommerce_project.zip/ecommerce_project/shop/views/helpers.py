from datetime import datetime

from django.shortcuts import redirect
from django.utils.http import url_has_allowed_host_and_scheme


def safe_next(request, default):
    """Return the 'next' URL only if it points to this site (blocks open redirects)."""
    target = request.POST.get("next") or request.GET.get("next") or ""
    if target and url_has_allowed_host_and_scheme(target, allowed_hosts={request.get_host()}):
        return target
    return default


def redirect_back(request, fallback):
    return redirect(safe_next(request, fallback))


def parse_date(text):
    """'2026-10-24' -> date, or None when blank/invalid."""
    try:
        return datetime.strptime((text or "").strip(), "%Y-%m-%d").date()
    except ValueError:
        return None


def parse_float(text):
    """'250' -> 250.0; blank, None, 'abc', 'nan' or 'inf' -> None."""
    try:
        value = float(str(text).strip())
    except (TypeError, ValueError):
        return None
    return value if value == value and abs(value) != float("inf") else None


def form_errors(request, form):
    """Show form errors as flash messages when the template does not."""
    from django.contrib import messages
    for field, errors in form.errors.items():
        for error in errors:
            label = "" if field == "__all__" else f"{form.fields[field].label or field}: "
            messages.error(request, f"{label}{error}")
