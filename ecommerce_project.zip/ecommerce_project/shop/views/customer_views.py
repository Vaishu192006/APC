import uuid

from django.contrib import messages
from django.core.exceptions import ValidationError
from django.shortcuts import redirect, render
from django.http import Http404
from django.views.decorators.http import require_POST

from ..decorators import customer_required, login_required_csv
from ..forms import ReviewForm
from ..services import cart_service, order_service, product_service
from ..services.cart_service import CartError
from ..services.order_service import OrderError
from ..services.recommender import get_recommender
from .helpers import form_errors, parse_float, redirect_back


# ---------------------------------------------------------------- browsing ---
def home(request):
    recommender = get_recommender()
    user = request.current_user
    if user and not user.is_admin:
        recommended, reason = recommender.for_customer(user.customer_id, 4)
    else:
        recommended, reason = recommender.popular(4), "Popular right now"
    return render(request, "shop/home.html", {
        "recommended": recommended, "reason": reason,
        "newest": product_service.search_products(sort="newest")[:8],
        "categories": product_service.list_categories(),
    })


def product_list(request):
    query = request.GET.get("q", "").strip()[:60]
    category = request.GET.get("category", "")
    min_price = parse_float(request.GET.get("min_price"))
    max_price = parse_float(request.GET.get("max_price"))
    sort = request.GET.get("sort", "newest")
    products = product_service.search_products(query, category, min_price, max_price, sort)
    return render(request, "shop/product_list.html", {
        "products": products, "categories": product_service.list_categories(),
        "q": query, "category": category, "sort": sort,
        "min_price": request.GET.get("min_price", ""), "max_price": request.GET.get("max_price", ""),
    })


def product_detail(request, product_id):
    product = product_service.get_product(product_id)
    if product is None:
        raise Http404("Product not found.")
    reviews = product_service.list_reviews(product_id)
    return render(request, "shop/product_detail.html", {
        "product": product, "reviews": reviews,
        "rating": product_service.average_rating(reviews),
        "review_form": ReviewForm(),
        "similar": get_recommender().similar_to(product_id, 4),
        "max_qty": min(product.stock, 10),
    })


@customer_required
@require_POST
def review_add(request, product_id):
    form = ReviewForm(request.POST)
    if form.is_valid():
        try:
            product_service.add_review(product_id, request.current_user.customer_id,
                                       form.cleaned_data["rating"], form.cleaned_data["comment"])
            messages.success(request, "Thanks for your review!")
        except ValidationError as exc:
            messages.error(request, "; ".join(exc.messages))
    else:
        form_errors(request, form)
    return redirect("shop:product_detail", product_id=product_id)


# -------------------------------------------------------------------- cart ---
@customer_required
def cart_view(request):
    cart = cart_service.build_cart(request.session)
    for problem in cart["problems"]:
        messages.warning(request, problem)
    return render(request, "shop/cart.html", {"cart": cart})


@customer_required
@require_POST
def cart_add(request, product_id):
    try:
        quantity = int(request.POST.get("quantity", 1))
        product = cart_service.add_item(request.session, product_id, quantity)
        messages.success(request, f"{product.name} added to your cart.")
    except (ValueError, CartError) as exc:
        messages.error(request, str(exc) if isinstance(exc, CartError) else "Enter a valid quantity.")
    return redirect_back(request, "shop:cart")


@customer_required
@require_POST
def cart_update(request, product_id):
    """Set an exact quantity, or step it up/down with action=inc / dec."""
    try:
        current = cart_service.get_cart(request.session).get(product_id, 0)
        action = request.POST.get("action")
        if action == "inc":
            quantity = current + 1
        elif action == "dec":
            quantity = current - 1
        else:
            quantity = int(request.POST.get("quantity", current))
        cart_service.set_quantity(request.session, product_id, quantity)
    except (ValueError, CartError) as exc:
        messages.error(request, str(exc) if isinstance(exc, CartError) else "Enter a valid quantity.")
    return redirect("shop:cart")


@customer_required
@require_POST
def cart_remove(request, product_id):
    cart_service.remove_item(request.session, product_id)
    messages.info(request, "Item removed from your cart.")
    return redirect("shop:cart")


# ---------------------------------------------------------------- checkout ---
@customer_required
def checkout(request):
    cart = cart_service.build_cart(request.session)
    if cart["is_empty"]:
        messages.warning(request, "Your cart is empty.")
        return redirect("shop:product_list")

    if request.method == "POST":
        token = request.POST.get("token", "")
        if token != request.session.get("checkout_token"):
            messages.error(request, "This checkout form has expired. Please review your cart.")
            return redirect("shop:cart")
        try:
            order = order_service.place_order(
                request.current_user.customer_id, cart_service.get_cart(request.session), token)
        except OrderError as exc:
            for text in exc.messages:
                messages.error(request, text)
            return redirect("shop:cart")
        cart_service.clear_cart(request.session)
        request.session.pop("checkout_token", None)
        messages.success(request, "Order placed successfully (demo checkout).")
        return redirect("shop:order_confirmation", order_id=order.order_id)

    token = request.session.get("checkout_token") or uuid.uuid4().hex
    request.session["checkout_token"] = token
    return render(request, "shop/checkout.html", {"cart": cart, "token": token})


@customer_required
def order_confirmation(request, order_id):
    order = order_service.get_order_for_user(order_id, request.current_user)
    return render(request, "shop/order_confirmation.html", {"order": order})


# ------------------------------------------------------------------ orders ---
@customer_required
def order_history(request):
    return render(request, "shop/order_history.html", {
        "orders": order_service.list_orders(customer_id=request.current_user.customer_id)})


@login_required_csv
def order_detail(request, order_id):
    order = order_service.get_order_for_user(order_id, request.current_user)
    return render(request, "shop/order_detail.html", {
        "order": order, "is_admin_view": False,
        "can_cancel": order.customer_can_cancel and not request.current_user.is_admin})


@customer_required
@require_POST
def order_cancel(request, order_id):
    try:
        order_service.change_status(order_id, "Cancelled", request.current_user)
        messages.success(request, "Order cancelled. Stock has been restored.")
    except OrderError as exc:
        messages.error(request, str(exc))
    return redirect("shop:order_detail", order_id=order_id)


@customer_required
def customer_dashboard(request):
    summary = order_service.customer_summary(request.current_user.customer_id)
    recommended, reason = get_recommender().for_customer(request.current_user.customer_id, 4)
    return render(request, "shop/customer_dashboard.html", {
        "summary": summary, "recent": summary["orders"][:5],
        "recommended": recommended, "reason": reason})
