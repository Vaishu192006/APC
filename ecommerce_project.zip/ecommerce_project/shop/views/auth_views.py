from django.contrib import messages
from django.core.exceptions import ValidationError
from django.shortcuts import redirect, render
from django.urls import reverse
from django.views.decorators.http import require_POST

from ..forms import LoginForm, RegisterForm
from ..services import auth_service
from ..services.auth_service import AccountLocked
from .helpers import safe_next


def _start_session(request, user):
    """Log a user in: new clean session (prevents session fixation), keep the guest cart."""
    cart = request.session.get("cart")
    request.session.flush()
    request.session["customer_id"] = user.customer_id
    request.session["role"] = user.role
    if cart and not user.is_admin:
        request.session["cart"] = cart


def register_view(request):
    if request.current_user:
        return redirect(request.current_user.home_url_name)
    form = RegisterForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        data = form.cleaned_data
        try:
            user = auth_service.register_customer(
                data["name"], data["email"], data["phone"], data["password"], data["address"])
        except ValidationError as exc:
            for field, errors in exc.message_dict.items():
                for error in errors:
                    form.add_error(field if field in form.fields else None, error)
        else:
            _start_session(request, user)
            messages.success(request, f"Welcome, {user.first_name}! Your account is ready.")
            return redirect("shop:home")
    return render(request, "shop/register.html", {"form": form})


def login_view(request):
    if request.current_user:
        return redirect(request.current_user.home_url_name)
    form = LoginForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        try:
            user = auth_service.authenticate(form.cleaned_data["email"], form.cleaned_data["password"])
        except AccountLocked as exc:
            messages.error(request, str(exc))
        else:
            if user is None:
                messages.error(request, "Incorrect email or password.")
            else:
                _start_session(request, user)
                messages.success(request, f"Welcome back, {user.first_name}!")
                return redirect(safe_next(request, reverse(user.home_url_name)))
    return render(request, "shop/login.html", {"form": form, "next": request.GET.get("next", "")})


@require_POST
def logout_view(request):
    request.session.flush()
    messages.info(request, "You have been logged out.")
    return redirect("shop:home")
