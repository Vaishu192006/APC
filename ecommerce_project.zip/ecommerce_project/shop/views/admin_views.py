from django.contrib import messages
from django.core.exceptions import ValidationError
from django.http import Http404
from django.shortcuts import redirect, render
from django.views.decorators.http import require_POST

from ..decorators import admin_required
from ..forms import CategoryForm, ProductForm
from ..services import analytics_service, auth_service, order_service, product_service
from ..services.order_service import OrderError
from ..storage.schemas import ORDER_STATUSES
from .helpers import form_errors, parse_date


@admin_required
def dashboard(request):
    report = analytics_service.build_report(with_charts=False)
    return render(request, "shop/admin/dashboard.html", {"r": report})


@admin_required
def analytics(request):
    date_from = parse_date(request.GET.get("date_from"))
    date_to = parse_date(request.GET.get("date_to"))
    if date_from and date_to and date_from > date_to:
        messages.error(request, "'From' date must be before 'To' date.")
        date_from = date_to = None
    report = analytics_service.build_report(date_from, date_to)
    return render(request, "shop/admin/analytics.html", {
        "r": report, "date_from": request.GET.get("date_from", ""),
        "date_to": request.GET.get("date_to", "")})


# ---------------------------------------------------------------- products ---
@admin_required
def product_list(request):
    query = request.GET.get("q", "").strip()[:60]
    products = product_service.search_products(query, request.GET.get("category", ""),
                                               include_inactive=True)
    return render(request, "shop/admin/product_list.html", {
        "products": products, "q": query,
        "category": request.GET.get("category", ""),
        "categories": product_service.list_categories()})


@admin_required
def product_add(request):
    if not product_service.list_categories():
        messages.warning(request, "Create a category first.")
        return redirect("shop:admin_categories")
    form = ProductForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        try:
            product = product_service.create_product(form.cleaned_data)
            messages.success(request, f"Product '{product.name}' added.")
            return redirect("shop:admin_products")
        except ValidationError as exc:
            form.add_error(None, exc)
    return render(request, "shop/admin/product_form.html", {"form": form, "title": "Add product"})


@admin_required
def product_edit(request, product_id):
    product = product_service.get_product(product_id, include_inactive=True)
    if product is None:
        raise Http404("Product not found.")
    initial = {"name": product.name, "description": product.description,
               "category_id": product.category_id, "price": f"{product.price:.2f}",
               "stock": product.stock, "image_path": product.image_path}
    form = ProductForm(request.POST or None, initial=initial)
    if request.method == "POST" and form.is_valid():
        try:
            product_service.update_product(product_id, form.cleaned_data)
            messages.success(request, "Product updated.")
            return redirect("shop:admin_products")
        except ValidationError as exc:
            form.add_error(None, exc)
    return render(request, "shop/admin/product_form.html",
                  {"form": form, "title": f"Edit {product.name}", "product": product})


@admin_required
@require_POST
def product_delete(request, product_id):
    try:
        result = product_service.delete_product(product_id)
        if result == "archived":
            messages.info(request, "Product is in past orders, so it was archived (hidden from the shop).")
        else:
            messages.success(request, "Product deleted.")
    except ValidationError as exc:
        messages.error(request, "; ".join(exc.messages))
    return redirect("shop:admin_products")


@admin_required
def categories(request):
    form = CategoryForm(request.POST or None)
    if request.method == "POST":
        if form.is_valid():
            try:
                product_service.add_category(form.cleaned_data["name"], form.cleaned_data["description"])
                messages.success(request, "Category added.")
                return redirect("shop:admin_categories")
            except ValidationError as exc:
                form.add_error("name", exc)
    counts = {}
    for p in product_service.all_products(include_inactive=True):
        counts[p.category_id] = counts.get(p.category_id, 0) + 1
    cats = [c | {"count": counts.get(c["category_id"], 0)} for c in product_service.list_categories()]
    return render(request, "shop/admin/category_list.html", {"form": form, "categories": cats})


@admin_required
@require_POST
def category_delete(request, category_id):
    try:
        product_service.delete_category(category_id)
        messages.success(request, "Category deleted.")
    except ValidationError as exc:
        messages.error(request, "; ".join(exc.messages))
    return redirect("shop:admin_categories")


# ------------------------------------------------------------------ orders ---
@admin_required
def order_list(request):
    status = request.GET.get("status", "")
    orders = order_service.list_orders(
        status=status if status in ORDER_STATUSES else "",
        search=request.GET.get("q", "")[:40],
        date_from=parse_date(request.GET.get("date_from")),
        date_to=parse_date(request.GET.get("date_to")))
    return render(request, "shop/admin/order_list.html", {
        "orders": orders, "statuses": ORDER_STATUSES, "status": status,
        "q": request.GET.get("q", ""), "date_from": request.GET.get("date_from", ""),
        "date_to": request.GET.get("date_to", "")})


@admin_required
def order_detail(request, order_id):
    order = order_service.get_order_for_user(order_id, request.current_user)
    return render(request, "shop/order_detail.html", {
        "order": order, "is_admin_view": True,
        "next_statuses": order_service.allowed_next_statuses(order)})


@admin_required
@require_POST
def order_status(request, order_id):
    try:
        order_service.change_status(order_id, request.POST.get("status", ""), request.current_user)
        messages.success(request, "Order status updated.")
    except OrderError as exc:
        messages.error(request, str(exc))
    return redirect("shop:admin_order_detail", order_id=order_id)


@admin_required
def customers(request):
    stats = {}
    for o in order_service.list_orders():
        s = stats.setdefault(o.customer_id, {"orders": 0, "spent": 0.0})
        s["orders"] += 1
        if o.counts_as_revenue:
            s["spent"] += o.total_amount
    rows = [{"user": u, **stats.get(u.customer_id, {"orders": 0, "spent": 0.0})}
            for u in auth_service.list_customers()]
    return render(request, "shop/admin/customer_list.html", {"rows": rows})
