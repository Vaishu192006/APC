/* Small enhancements; the site still works without JavaScript. */
document.addEventListener("DOMContentLoaded", function () {
  // 1. Missing product image -> local placeholder (guard prevents an endless loop)
  document.querySelectorAll("img[data-fallback]").forEach(function (img) {
    img.addEventListener("error", function () {
      if (img.dataset.failed) return;
      img.dataset.failed = "1";
      img.src = "/static/shop/img/placeholder.svg";
    });
  });

  // 2. Stop double submission: disable the submit button after the first click
  document.querySelectorAll("form[data-once]").forEach(function (form) {
    form.addEventListener("submit", function () {
      form.querySelectorAll("button[type=submit]").forEach(function (b) {
        b.disabled = true;
        b.textContent = "Please wait...";
      });
    });
  });

  // 3. Ask before risky actions (delete, cancel, change status)
  document.querySelectorAll("form[data-confirm]").forEach(function (form) {
    form.addEventListener("submit", function (e) {
      if (!window.confirm(form.dataset.confirm)) e.preventDefault();
    });
  });
});
