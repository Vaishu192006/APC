import logging

from django.apps import AppConfig

logger = logging.getLogger(__name__)


class ShopConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "shop"

    def ready(self):
        """Create any missing CSV files (with headers) when the server starts."""
        from .storage.csv_store import ensure_all
        try:
            ensure_all()
        except Exception as exc:  # never stop Django from starting
            logger.warning("Could not prepare CSV files: %s", exc)
