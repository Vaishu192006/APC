"""Access control decorators (our replacement for Django's @login_required)."""
from functools import wraps
from urllib.parse import urlencode

from django.contrib import messages
from django.core.exceptions import PermissionDenied
from django.shortcuts import redirect
from django.urls import reverse


def _to_login(request):
    messages.warning(request, "Please log in to continue.")
    return redirect(f"{reverse('shop:login')}?{urlencode({'next': request.get_full_path()})}")


def login_required_csv(view):
    @wraps(view)
    def wrapper(request, *args, **kwargs):
        if request.current_user is None:
            return _to_login(request)
        return view(request, *args, **kwargs)
    return wrapper


def customer_required(view):
    """Only logged-in customers (admins cannot shop)."""
    @wraps(view)
    def wrapper(request, *args, **kwargs):
        user = request.current_user
        if user is None:
            return _to_login(request)
        if user.is_admin:
            raise PermissionDenied("Administrators cannot use the shopping cart.")
        return view(request, *args, **kwargs)
    return wrapper


def admin_required(view):
    @wraps(view)
    def wrapper(request, *args, **kwargs):
        user = request.current_user
        if user is None:
            return _to_login(request)
        if not user.is_admin:
            raise PermissionDenied("Administrator access only.")
        return view(request, *args, **kwargs)
    return wrapper
