from django.conf import settings

from .services import cart_service


def shop_globals(request):
    """Variables available in every template."""
    session = getattr(request, "session", {})
    return {
        "current_user": getattr(request, "current_user", None),
        "cart_count": cart_service.cart_count(session),
        "CURRENCY": settings.CURRENCY_SYMBOL,
        "TAX_LABEL": settings.TAX_LABEL,
        "TAX_PERCENT": round(settings.TAX_RATE * 100, 2),
    }
