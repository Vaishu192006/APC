"""
validators.py - input validation using regular expressions (the `re` module).

Every function returns a cleaned value or raises Django's ValidationError,
so they can be used both inside forms and inside services.
"""
import re

from django.core.exceptions import ValidationError

# Compiled patterns (compiled once, reused many times)
EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")
PHONE_RE = re.compile(r"^[6-9]\d{9}$")                       # 10-digit Indian mobile
NAME_RE = re.compile(r"^[A-Za-z][A-Za-z .'-]{1,59}$")
PASSWORD_RE = re.compile(r"^(?=.*[A-Za-z])(?=.*\d).{8,64}$")   # letters + digits, 8-64
PRODUCT_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 .,&()'\"/+-]{1,99}$")
IMAGE_PATH_RE = re.compile(r"^(https?://[^\s<>\"']+|[A-Za-z0-9_./-]+)$")
TOKEN_RE = re.compile(r"^[a-f0-9]{32}$")
ORDER_ID_RE = re.compile(r"^ORD-\d{8}-[A-F0-9]{6}$")

# Spreadsheet programs treat these leading characters as formulas
_FORMULA_START = ("=", "+", "-", "@")


def validate_name(value):
    value = " ".join(str(value).split())          # tidy extra spaces
    if not NAME_RE.match(value):
        raise ValidationError("Enter a valid name (letters and spaces only, 2-60 characters).")
    return value


def validate_email(value):
    value = str(value).strip().lower()
    if len(value) > 100 or not EMAIL_RE.match(value):
        raise ValidationError("Enter a valid email address.")
    return value


def validate_phone(value):
    value = re.sub(r"[\s-]", "", str(value))      # remove spaces and dashes
    if not PHONE_RE.match(value):
        raise ValidationError("Enter a valid 10-digit mobile number starting with 6-9.")
    return value


def validate_password(value):
    if not PASSWORD_RE.match(str(value)):
        raise ValidationError("Password must be 8-64 characters and contain letters and digits.")
    return value


def validate_product_name(value):
    value = " ".join(str(value).split())
    if not PRODUCT_NAME_RE.match(value):
        raise ValidationError("Product name must be 2-100 characters (letters, digits, basic punctuation).")
    return value


def validate_text(value, field="Text", max_len=500, required=False):
    """Clean free text: trim, limit length, block spreadsheet formula injection."""
    value = " ".join(str(value or "").split())
    if required and not value:
        raise ValidationError(f"{field} is required.")
    if len(value) > max_len:
        raise ValidationError(f"{field} must be at most {max_len} characters.")
    if value.startswith(_FORMULA_START):
        raise ValidationError(f"{field} cannot start with = + - or @.")
    return value


def validate_price(value):
    try:
        price = round(float(value), 2)
    except (TypeError, ValueError):
        raise ValidationError("Enter a valid price.")
    if price < 0:
        raise ValidationError("Price cannot be negative.")
    if price > 10_000_000:
        raise ValidationError("Price is too large.")
    return price


def validate_stock(value):
    try:
        stock = int(value)
    except (TypeError, ValueError):
        raise ValidationError("Enter a whole number for stock.")
    if stock < 0:
        raise ValidationError("Stock cannot be negative.")
    if stock > 1_000_000:
        raise ValidationError("Stock value is too large.")
    return stock


def validate_image_path(value):
    value = str(value or "").strip()
    if not value:
        return ""
    if ".." in value or not IMAGE_PATH_RE.match(value):
        raise ValidationError("Image must be an http(s) link or a simple relative path.")
    return value


def validate_rating(value):
    try:
        rating = int(value)
    except (TypeError, ValueError):
        raise ValidationError("Choose a rating from 1 to 5.")
    if not 1 <= rating <= 5:
        raise ValidationError("Choose a rating from 1 to 5.")
    return rating
