"""
recommender.py - content-based product recommendations (Scikit-learn).

HOW IT WORKS (simple version for the viva)
  1. For every product we build one text: name + category (repeated 3 times, so
     it matters more) + description.
  2. TfidfVectorizer turns each text into a vector of word importance (TF-IDF).
  3. cosine_similarity measures how close two vectors are (0 = nothing in
     common, 1 = identical).
  4. SIMILAR PRODUCTS  : products with the highest similarity to one product.
  5. FOR A CUSTOMER    : average the vectors of products they bought (a "taste
     profile") and recommend the most similar products they have not bought.
  6. FALLBACK          : new customers (no purchases) or empty results get the
     best-selling products, then the newest products.

LIMITATIONS
  * Uses text only: it does not learn from what OTHER customers buy
    (no collaborative filtering), so it cannot find surprising matches.
  * Quality depends on good product descriptions.
  * Rebuilt on every request - fine for hundreds of products, not millions.
  * Needs at least 2 products to compute similarity.
"""
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from ..storage.csv_store import read_rows, to_int
from ..storage.schemas import REVENUE_STATUSES
from . import product_service


class ProductRecommender:
    def __init__(self):
        self.products = product_service.all_products()
        self.index = {p.product_id: i for i, p in enumerate(self.products)}
        self.matrix = None
        texts = [f"{p.name} {(p.category_name + ' ') * 3}{p.description}" for p in self.products]
        if len(texts) >= 2:
            try:
                self.matrix = TfidfVectorizer(stop_words="english").fit_transform(texts)
            except ValueError:            # empty vocabulary (e.g. only stop-words)
                self.matrix = None

    # ---- helpers ----
    def _units_sold(self):
        paid = {o["order_id"] for o in read_rows("orders") if o["status"] in REVENUE_STATUSES}
        sold = {}
        for item in read_rows("order_items"):
            if item["order_id"] in paid:
                sold[item["product_id"]] = sold.get(item["product_id"], 0) + to_int(item["quantity"])
        return sold

    def popular(self, n=4, exclude=()):
        """Fallback: best sellers first, then newest products."""
        sold = self._units_sold()
        pool = [p for p in self.products if p.in_stock and p.product_id not in exclude]
        pool.sort(key=lambda p: (sold.get(p.product_id, 0), p.created_at), reverse=True)
        return pool[:n]

    def _top(self, scores, n, exclude):
        order = np.argsort(scores)[::-1]
        picks = []
        for i in order:
            product = self.products[i]
            if scores[i] <= 0 or product.product_id in exclude or not product.in_stock:
                continue
            picks.append(product)
            if len(picks) == n:
                break
        return picks

    # ---- public API ----
    def similar_to(self, product_id, n=4):
        """Products most similar to one product (for the product page)."""
        if self.matrix is None or product_id not in self.index:
            return self.popular(n, exclude={product_id})
        i = self.index[product_id]
        scores = cosine_similarity(self.matrix[i], self.matrix).ravel()
        picks = self._top(scores, n, exclude={product_id})
        if len(picks) < n:                                   # pad with fallback
            picks += self.popular(n - len(picks), exclude={product_id} | {p.product_id for p in picks})
        return picks

    def for_customer(self, customer_id, n=4):
        """Returns (products, explanation) for the home page."""
        bought = self._bought_by(customer_id)
        if not bought or self.matrix is None:
            return self.popular(n), "Popular right now"
        rows = [self.index[pid] for pid in bought if pid in self.index]
        if not rows:
            return self.popular(n), "Popular right now"
        profile = np.asarray(self.matrix[rows].mean(axis=0))          # taste profile
        scores = cosine_similarity(profile, self.matrix).ravel()
        picks = self._top(scores, n, exclude=set(bought))
        if len(picks) < n:
            picks += self.popular(n - len(picks), exclude=set(bought) | {p.product_id for p in picks})
        return picks, "Picked for you, based on your past orders"

    def _bought_by(self, customer_id):
        mine = {o["order_id"] for o in read_rows("orders")
                if o["customer_id"] == customer_id and o["status"] != "Cancelled"}
        return {i["product_id"] for i in read_rows("order_items") if i["order_id"] in mine}


def get_recommender():
    return ProductRecommender()
