"""
auth_service.py - registration, login and user lookup (no SQL database).

Security notes
  * Passwords are hashed with Django's PBKDF2 hasher (never stored in plain text).
  * Login attempts are rate-limited per email address (in memory).
  * Session data is kept in a signed cookie (see settings.py).
"""
import threading
import time

from django.contrib.auth.hashers import check_password, make_password
from django.core.exceptions import ValidationError

from ..models import build_user
from ..storage.csv_store import now_iso, next_id, read_rows, transaction, write_rows

MAX_FAILED_ATTEMPTS = 5
LOCKOUT_SECONDS = 300

_failed = {}                 # email -> list of failure timestamps
_failed_lock = threading.Lock()
_dummy_hash = None           # used so unknown emails take the same time as wrong passwords


class AccountLocked(Exception):
    """Too many failed login attempts."""


def _recent_failures(email):
    cutoff = time.time() - LOCKOUT_SECONDS
    with _failed_lock:
        attempts = [t for t in _failed.get(email, []) if t > cutoff]
        _failed[email] = attempts
        return len(attempts)


def _register_failure(email):
    with _failed_lock:
        _failed.setdefault(email, []).append(time.time())


def reset_login_limits():
    """Clear the failure counters (used by tests)."""
    with _failed_lock:
        _failed.clear()


def register_customer(name, email, phone, password, address=""):
    """Create a new customer. Raises ValidationError if email/phone already used."""
    password_hash = make_password(password)        # slow on purpose; done before locking
    with transaction("customers"):
        rows = read_rows("customers")
        if any(r["email"].lower() == email.lower() for r in rows):
            raise ValidationError({"email": "An account with this email already exists."})
        if any(r["phone"] == phone for r in rows):
            raise ValidationError({"phone": "This phone number is already registered."})
        row = {
            "customer_id": next_id("customers", rows),
            "name": name,
            "email": email.lower(),
            "phone": phone,
            "password_hash": password_hash,
            "role": "customer",
            "address": address,
            "created_at": now_iso(),
        }
        rows.append(row)
        write_rows("customers", rows)
    return build_user(row)


def authenticate(email, password):
    """Return the user if the credentials are right, otherwise None.

    Raises AccountLocked after too many failed attempts.
    """
    global _dummy_hash
    email = (email or "").strip().lower()
    if _recent_failures(email) >= MAX_FAILED_ATTEMPTS:
        raise AccountLocked("Too many failed attempts. Try again in a few minutes.")

    row = next((r for r in read_rows("customers") if r["email"].lower() == email), None)
    if row is None:
        if _dummy_hash is None:
            _dummy_hash = make_password("not-a-real-password")
        check_password(password, _dummy_hash)       # keep timing similar
        _register_failure(email)
        return None

    user = build_user(row | {"password_hash": row["password_hash"]})
    if user.check_password(password):
        with _failed_lock:
            _failed.pop(email, None)
        return user
    _register_failure(email)
    return None


def get_user(customer_id):
    """Look a user up by ID (None if not found)."""
    for row in read_rows("customers"):
        if row["customer_id"] == customer_id:
            return build_user(row)
    return None


def list_customers():
    """All users with the 'customer' role."""
    return [build_user(r) for r in read_rows("customers") if r["role"] == "customer"]


def customer_name_map():
    """{customer_id: name} - used to show names next to orders."""
    return {r["customer_id"]: r["name"] for r in read_rows("customers")}
