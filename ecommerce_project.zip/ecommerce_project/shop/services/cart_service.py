"""
cart_service.py - the shopping cart.

The cart is stored in the session as {product_id: quantity}. Nothing is
written to CSV until the customer places an order.
"""
from django.conf import settings

from . import product_service


class CartError(Exception):
    """A cart action was not allowed (e.g. not enough stock)."""


def calculate_totals(subtotal):
    """Return (subtotal, tax, total) rounded to 2 decimals. Tax rate is in settings."""
    subtotal = round(subtotal, 2)
    tax = round(subtotal * settings.TAX_RATE, 2)
    return subtotal, tax, round(subtotal + tax, 2)


def get_cart(session):
    cart = session.get("cart", {})
    return dict(cart) if isinstance(cart, dict) else {}


def _save(session, cart):
    session["cart"] = cart
    session.modified = True


def cart_count(session):
    try:
        return sum(int(q) for q in get_cart(session).values())
    except (TypeError, ValueError):
        return 0


def _check_quantity(product, quantity):
    if product is None:
        raise CartError("This product is no longer available.")
    if product.stock <= 0:
        raise CartError(f"{product.name} is out of stock.")
    if quantity > settings.MAX_QTY_PER_ITEM:
        raise CartError(f"You can order at most {settings.MAX_QTY_PER_ITEM} units of one product.")
    if quantity > product.stock:
        raise CartError(f"Only {product.stock} unit(s) of {product.name} are available.")


def add_item(session, product_id, quantity=1):
    product = product_service.get_product(product_id)
    cart = get_cart(session)
    new_quantity = cart.get(product_id, 0) + quantity
    if quantity < 1:
        raise CartError("Quantity must be at least 1.")
    _check_quantity(product, new_quantity)
    cart[product_id] = new_quantity
    _save(session, cart)
    return product


def set_quantity(session, product_id, quantity):
    cart = get_cart(session)
    if product_id not in cart:
        raise CartError("This item is not in your cart.")
    if quantity < 1:
        cart.pop(product_id)
    else:
        _check_quantity(product_service.get_product(product_id), quantity)
        cart[product_id] = quantity
    _save(session, cart)


def remove_item(session, product_id):
    cart = get_cart(session)
    cart.pop(product_id, None)
    _save(session, cart)


def clear_cart(session):
    _save(session, {})


def build_cart(session):
    """Return a dict with the cart lines, totals and any problems found."""
    cart = get_cart(session)
    lines, problems, cleaned = [], [], {}
    for product_id, quantity in cart.items():
        product = product_service.get_product(product_id)
        if product is None:
            problems.append("An item was removed because it is no longer available.")
            continue
        quantity = int(quantity)
        if product.stock <= 0:
            problems.append(f"{product.name} is out of stock and was removed.")
            continue
        if quantity > product.stock:
            problems.append(f"{product.name}: quantity reduced to {product.stock} (stock limit).")
            quantity = product.stock
        cleaned[product_id] = quantity
        lines.append({"product": product, "quantity": quantity,
                      "line_total": round(product.price * quantity, 2)})
    if cleaned != cart:
        _save(session, cleaned)
    subtotal, tax, total = calculate_totals(sum(l["line_total"] for l in lines))
    return {"lines": lines, "subtotal": subtotal, "tax": tax, "total": total,
            "problems": problems, "is_empty": not lines}
