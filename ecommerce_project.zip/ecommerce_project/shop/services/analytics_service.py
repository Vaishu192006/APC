"""
analytics_service.py - sales analytics with Pandas, NumPy and Matplotlib.

Revenue rule (used everywhere):
    Revenue = total_amount (including tax) of orders whose status is
    Confirmed, Shipped or Delivered.  Pending and Cancelled orders are NOT revenue.
"""
import base64
import io

import numpy as np
import pandas as pd
from django.conf import settings
from matplotlib.figure import Figure

from ..storage.csv_store import ensure_file
from ..storage.schemas import REVENUE_STATUSES, SCHEMAS, csv_path

PALETTE = {"main": "#0f766e", "accent": "#f59e0b", "ink": "#12263a", "grid": "#d9e2e6"}


# ---------------------------------------------------------------- loading ---
def load_frame(name):
    """Read a CSV into a DataFrame. Empty/malformed files give an empty frame."""
    ensure_file(name)
    columns = list(SCHEMAS[name])
    try:
        df = pd.read_csv(csv_path(name), dtype=str, keep_default_na=False,
                         on_bad_lines="skip", encoding="utf-8-sig")
    except (pd.errors.EmptyDataError, pd.errors.ParserError):
        df = pd.DataFrame(columns=columns)
    for col in columns:
        if col not in df.columns:
            df[col] = ""
    return df[columns]


def _numeric(df, columns):
    for col in columns:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
    return df


def _load_orders(date_from=None, date_to=None):
    orders = _numeric(load_frame("orders"), ["subtotal", "tax_amount", "total_amount"])
    orders["order_date"] = pd.to_datetime(orders["order_date"], errors="coerce")
    orders = orders.dropna(subset=["order_date"])
    if date_from:
        orders = orders[orders["order_date"].dt.date >= date_from]
    if date_to:
        orders = orders[orders["order_date"].dt.date <= date_to]
    return orders


# ----------------------------------------------------------------- charts ---
def _png(fig):
    buffer = io.BytesIO()
    fig.savefig(buffer, format="png", dpi=110, bbox_inches="tight")
    return base64.b64encode(buffer.getvalue()).decode("ascii")


def _style(ax, title, ylabel=""):
    ax.set_title(title, loc="left", fontsize=11, fontweight="bold", color=PALETTE["ink"])
    ax.set_ylabel(ylabel, color=PALETTE["ink"])
    ax.grid(axis="y", color=PALETTE["grid"], linewidth=0.8)
    ax.set_axisbelow(True)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)


def _empty_chart(title):
    fig = Figure(figsize=(7, 3))
    ax = fig.subplots()
    ax.text(0.5, 0.5, "No sales data for this period", ha="center", va="center", color="#6b7c86")
    ax.set_axis_off()
    ax.set_title(title, loc="left", fontsize=11, fontweight="bold")
    return _png(fig)


def chart_daily(daily):
    title = f"Daily sales ({settings.CURRENCY_SYMBOL})"
    if daily.empty or daily.sum() == 0:
        return _empty_chart(title)
    values = daily.to_numpy(dtype=float)
    fig = Figure(figsize=(8, 3.4))
    ax = fig.subplots()
    ax.bar(daily.index, values, color=PALETTE["main"], alpha=0.35, width=0.8, label="Daily")
    window = min(7, len(values))
    trend = np.convolve(values, np.ones(window) / window, mode="valid")   # moving average
    ax.plot(daily.index[window - 1:], trend, color=PALETTE["accent"], linewidth=2.2,
            label=f"{window}-day average")
    _style(ax, title)
    ax.legend(frameon=False)
    fig.autofmt_xdate()
    return _png(fig)


def chart_monthly(monthly):
    title = f"Monthly sales ({settings.CURRENCY_SYMBOL})"
    if monthly.empty or monthly.sum() == 0:
        return _empty_chart(title)
    fig = Figure(figsize=(6, 3.4))
    ax = fig.subplots()
    labels = [str(p) for p in monthly.index]
    ax.bar(labels, monthly.to_numpy(dtype=float), color=PALETTE["main"])
    _style(ax, title)
    return _png(fig)


def chart_barh(series, title):
    if series.empty or series.sum() == 0:
        return _empty_chart(title)
    series = series.sort_values()
    fig = Figure(figsize=(6, 3.4))
    ax = fig.subplots()
    ax.barh([str(i)[:28] for i in series.index], series.to_numpy(dtype=float), color=PALETTE["main"])
    _style(ax, title)
    ax.grid(axis="x", color=PALETTE["grid"], linewidth=0.8)
    ax.grid(axis="y", visible=False)
    return _png(fig)


# -------------------------------------------------------------- dashboard ---
def build_report(date_from=None, date_to=None, with_charts=True):
    """Return every number and chart the dashboards need (as plain Python types)."""
    orders = _load_orders(date_from, date_to)
    products = _numeric(load_frame("products"), ["price", "stock"])
    products = products[products["is_active"] == "1"]
    customers = load_frame("customers")
    categories = load_frame("categories")
    items = _numeric(load_frame("order_items"), ["unit_price", "quantity", "line_total"])

    paid = orders[orders["status"].isin(REVENUE_STATUSES)]          # eligible orders
    revenue = float(paid["total_amount"].sum())
    avg_order = float(np.mean(paid["total_amount"])) if len(paid) else 0.0

    paid_items = items[items["order_id"].isin(paid["order_id"])]
    sold = paid_items.groupby("product_id")["quantity"].sum()

    # units sold per active product (0 for products never sold)
    perf = products[["product_id", "name", "category_id", "stock"]].copy()
    perf["units"] = perf["product_id"].map(sold).fillna(0).astype(int)
    best = perf.sort_values(["units", "name"], ascending=[False, True]).head(5)
    least = perf.sort_values(["units", "name"], ascending=[True, True]).head(5)

    # daily / monthly sales
    if len(paid):
        daily = paid.groupby(paid["order_date"].dt.date)["total_amount"].sum()
        full_range = pd.date_range(min(daily.index), max(daily.index), freq="D").date
        daily = daily.reindex(full_range, fill_value=0.0)
        monthly = paid.groupby(paid["order_date"].dt.to_period("M"))["total_amount"].sum()
    else:
        daily = pd.Series(dtype=float)
        monthly = pd.Series(dtype=float)

    # category sales (before tax) via product -> category lookup
    cat_names = dict(zip(categories["category_id"], categories["name"]))
    prod_cat = dict(zip(load_frame("products")["product_id"], load_frame("products")["category_id"]))
    if len(paid_items):
        by_cat = paid_items.assign(
            category=paid_items["product_id"].map(prod_cat).map(cat_names).fillna("Other")
        ).groupby("category")["line_total"].sum().sort_values(ascending=False)
    else:
        by_cat = pd.Series(dtype=float)

    low = products[products["stock"] <= settings.LOW_STOCK_THRESHOLD].sort_values("stock")
    names = dict(zip(customers["customer_id"], customers["name"]))
    recent = orders.sort_values("order_date", ascending=False).head(5)

    report = {
        "revenue": round(revenue, 2),
        "total_orders": int(len(orders)),
        "paid_orders": int(len(paid)),
        "cancelled_orders": int((orders["status"] == "Cancelled").sum()),
        "pending_orders": int((orders["status"] == "Pending").sum()),
        "total_products": int(len(products)),
        "total_customers": int((customers["role"] == "customer").sum()),
        "avg_order_value": round(avg_order, 2),
        "best_selling": best.to_dict("records"),
        "least_selling": least.to_dict("records"),
        "category_sales": [{"category": k, "amount": round(float(v), 2)} for k, v in by_cat.items()],
        "monthly_sales": [{"month": str(k), "amount": round(float(v), 2)} for k, v in monthly.items()],
        "daily_sales": [{"day": str(k), "amount": round(float(v), 2)} for k, v in daily.tail(14).items()],
        "low_stock": low[["product_id", "name", "stock"]].to_dict("records"),
        "recent_orders": [
            {"order_id": r.order_id, "customer": names.get(r.customer_id, r.customer_id),
             "date": r.order_date.strftime("%Y-%m-%d %H:%M"), "total": float(r.total_amount),
             "status": r.status}
            for r in recent.itertuples()
        ],
    }
    if with_charts:
        report["charts"] = {
            "daily": chart_daily(daily),
            "monthly": chart_monthly(monthly),
            "category": chart_barh(by_cat, f"Category sales, before tax ({settings.CURRENCY_SYMBOL})"),
            "top_products": chart_barh(best.set_index("name")["units"].astype(float), "Top products (units sold)"),
        }
    return report
