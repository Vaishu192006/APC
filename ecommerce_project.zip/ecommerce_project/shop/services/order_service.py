"""
order_service.py - placing, viewing, cancelling and updating orders.

How simultaneous orders are handled
  place_order() locks customers, products, orders and order_items together
  (see csv_store.transaction). Stock is re-checked INSIDE the lock, so two
  customers cannot both buy the last unit. All changes are calculated in
  memory first and written at the end.
"""
import uuid
from datetime import datetime

from django.conf import settings
from django.http import Http404

from ..models import Order, OrderItem
from ..storage.csv_store import next_id, read_rows, to_int, transaction, write_rows
from ..storage.schemas import CUSTOMER_CANCELLABLE, ORDER_STATUSES, STATUS_TRANSITIONS
from . import auth_service
from .cart_service import calculate_totals
from .validators import TOKEN_RE


class OrderError(Exception):
    """An order action failed. `messages` holds user-friendly reasons."""

    def __init__(self, messages):
        self.messages = [messages] if isinstance(messages, str) else list(messages)
        super().__init__("; ".join(self.messages))


def _new_order_id(existing_ids):
    while True:
        order_id = f"ORD-{datetime.now():%Y%m%d}-{uuid.uuid4().hex[:6].upper()}"
        if order_id not in existing_ids:
            return order_id


def place_order(customer_id, cart, token):
    """Create an order from the cart. Returns the Order.

    * Re-validates every product and stock level inside the lock.
    * `token` makes the call idempotent: submitting the same checkout form
      twice returns the first order instead of creating a duplicate.
    """
    if not cart:
        raise OrderError("Your cart is empty.")
    if not TOKEN_RE.match(token or ""):
        raise OrderError("This checkout form is invalid or expired. Please try again.")

    with transaction("customers", "products", "orders", "order_items"):
        if not any(c["customer_id"] == customer_id for c in read_rows("customers")):
            raise OrderError("Customer account not found.")

        orders = read_rows("orders")
        for existing in orders:                                # duplicate submission
            if existing["idempotency_token"] == token:
                return Order.from_row(existing)

        products = read_rows("products")
        by_id = {p["product_id"]: p for p in products}
        errors, lines = [], []
        for product_id, quantity in cart.items():
            quantity = to_int(quantity)
            row = by_id.get(product_id)
            if row is None or row["is_active"] != "1":
                errors.append("A product in your cart is no longer available.")
                continue
            stock = to_int(row["stock"])
            if quantity < 1:
                errors.append(f"Invalid quantity for {row['name']}.")
            elif quantity > stock:
                errors.append(f"Only {stock} unit(s) of {row['name']} left; you asked for {quantity}.")
            else:
                lines.append((row, quantity))
        if errors:
            raise OrderError(errors)

        item_rows = read_rows("order_items")
        order_id = _new_order_id({o["order_id"] for o in orders})
        new_items = []
        for row, quantity in lines:
            unit_price = float(row["price"])
            new_items.append({
                "item_id": next_id("order_items", item_rows + new_items),
                "order_id": order_id, "product_id": row["product_id"],
                "product_name": row["name"], "unit_price": f"{unit_price:.2f}",
                "quantity": str(quantity), "line_total": f"{unit_price * quantity:.2f}",
            })
            row["stock"] = str(to_int(row["stock"]) - quantity)     # reduce inventory

        subtotal, tax, total = calculate_totals(sum(float(i["line_total"]) for i in new_items))
        order_row = {
            "order_id": order_id, "customer_id": customer_id,
            "order_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "subtotal": f"{subtotal:.2f}", "tax_rate": str(settings.TAX_RATE),
            "tax_amount": f"{tax:.2f}", "total_amount": f"{total:.2f}",
            "status": "Pending", "idempotency_token": token,
        }
        write_rows("order_items", item_rows + new_items)
        write_rows("orders", orders + [order_row])
        write_rows("products", products)                           # stock written last
    return Order.from_row(order_row)


def get_items(order_id):
    return [OrderItem.from_row(r) for r in read_rows("order_items") if r["order_id"] == order_id]


def get_order_for_user(order_id, user):
    """Return an Order with its items, or raise Http404.

    Customers can only open their own orders; a foreign order looks the same
    as a missing one (no information leak).
    """
    for row in read_rows("orders"):
        if row["order_id"] == order_id:
            if not user.is_admin and row["customer_id"] != user.customer_id:
                break
            order = Order.from_row(row)
            order.items = get_items(order_id)
            order.customer_name = auth_service.customer_name_map().get(order.customer_id, "")
            return order
    raise Http404("Order not found.")


def list_orders(customer_id=None, status="", search="", date_from=None, date_to=None):
    """Orders (newest first) with optional filters. date_* are date objects."""
    names = auth_service.customer_name_map()
    search = (search or "").strip().lower()
    result = []
    for row in read_rows("orders"):
        if customer_id and row["customer_id"] != customer_id:
            continue
        if status and row["status"] != status:
            continue
        order = Order.from_row(row)
        order.customer_name = names.get(order.customer_id, "")
        if search and search not in order.order_id.lower() and search not in order.customer_name.lower():
            continue
        day = order.order_date[:10]
        if date_from and day < date_from.isoformat():
            continue
        if date_to and day > date_to.isoformat():
            continue
        result.append(order)
    return sorted(result, key=lambda o: o.order_date, reverse=True)


def change_status(order_id, new_status, user):
    """Change an order's status with all safety rules.

    * Admin: any move allowed by STATUS_TRANSITIONS.
    * Customer: may only cancel their OWN order while Pending/Confirmed.
    * Cancelling restores stock exactly once.
    """
    if new_status not in ORDER_STATUSES:
        raise OrderError("Unknown status.")
    with transaction("orders", "products", "order_items"):
        orders = read_rows("orders")
        row = next((o for o in orders if o["order_id"] == order_id), None)
        if row is None or (not user.is_admin and row["customer_id"] != user.customer_id):
            raise Http404("Order not found.")
        current = row["status"]
        if new_status not in STATUS_TRANSITIONS.get(current, set()):
            raise OrderError(f"An order that is {current} cannot be changed to {new_status}.")
        if not user.is_admin and (new_status != "Cancelled" or current not in CUSTOMER_CANCELLABLE):
            raise OrderError("You can only cancel an order before it is shipped.")

        if new_status == "Cancelled":                              # give stock back
            products = read_rows("products")
            by_id = {p["product_id"]: p for p in products}
            for item in read_rows("order_items"):
                if item["order_id"] == order_id and item["product_id"] in by_id:
                    p = by_id[item["product_id"]]
                    p["stock"] = str(to_int(p["stock"]) + to_int(item["quantity"]))
            write_rows("products", products)
        row["status"] = new_status
        write_rows("orders", orders)


def allowed_next_statuses(order):
    return sorted(STATUS_TRANSITIONS.get(order.status, set()), key=ORDER_STATUSES.index)


def customer_summary(customer_id):
    """Small stats for the customer dashboard."""
    orders = list_orders(customer_id=customer_id)
    spent = sum(o.total_amount for o in orders if o.counts_as_revenue)
    return {"orders": orders, "count": len(orders), "spent": round(spent, 2),
            "active": sum(1 for o in orders if o.status in ("Pending", "Confirmed", "Shipped"))}
