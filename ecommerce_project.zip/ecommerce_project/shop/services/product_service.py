"""product_service.py - categories, products, search/filter and reviews."""
from django.conf import settings
from django.core.exceptions import ValidationError

from ..models import Product
from ..storage.csv_store import (find_one, next_id, now_iso, read_rows, to_float,
                                 transaction, write_rows)


# ------------------------------------------------------------- categories ---
def list_categories():
    return sorted(read_rows("categories"), key=lambda c: c["name"].lower())


def category_map():
    return {c["category_id"]: c["name"] for c in read_rows("categories")}


def add_category(name, description=""):
    with transaction("categories"):
        rows = read_rows("categories")
        if any(r["name"].lower() == name.lower() for r in rows):
            raise ValidationError("A category with this name already exists.")
        rows.append({"category_id": next_id("categories", rows), "name": name,
                     "description": description})
        write_rows("categories", rows)


def delete_category(category_id):
    """Delete a category only if no product uses it."""
    with transaction("categories", "products"):
        if any(p["category_id"] == category_id for p in read_rows("products")):
            raise ValidationError("This category still has products. Move or delete them first.")
        rows = read_rows("categories")
        remaining = [r for r in rows if r["category_id"] != category_id]
        if len(remaining) == len(rows):
            raise ValidationError("Category not found.")
        write_rows("categories", remaining)


# ---------------------------------------------------------------- products ---
def _to_products(rows):
    names = category_map()
    products = []
    for row in rows:
        product = Product.from_row(row)
        product.category_name = names.get(product.category_id, "Uncategorised")
        products.append(product)
    return products


def all_products(include_inactive=False):
    products = _to_products(read_rows("products"))
    return products if include_inactive else [p for p in products if p.is_active]


def get_product(product_id, include_inactive=False):
    for product in all_products(include_inactive=True):
        if product.product_id == product_id:
            return product if (product.is_active or include_inactive) else None
    return None


SORTS = {
    "newest": (lambda p: p.created_at, True),
    "price_asc": (lambda p: p.price, False),
    "price_desc": (lambda p: p.price, True),
    "name": (lambda p: p.name.lower(), False),
}


def search_products(query="", category_id="", min_price=None, max_price=None,
                    sort="newest", include_inactive=False):
    """Search by name/category text, then filter by category and price range."""
    query = (query or "").strip().lower()
    results = []
    for p in all_products(include_inactive=include_inactive):
        if query and query not in p.name.lower() and query not in p.category_name.lower():
            continue
        if category_id and p.category_id != category_id:
            continue
        if min_price is not None and p.price < min_price:
            continue
        if max_price is not None and p.price > max_price:
            continue
        results.append(p)
    key, reverse = SORTS.get(sort, SORTS["newest"])
    return sorted(results, key=key, reverse=reverse)


def low_stock_products():
    """Active products at or below the low-stock threshold (lowest first)."""
    limit = settings.LOW_STOCK_THRESHOLD
    return sorted((p for p in all_products() if p.stock <= limit), key=lambda p: p.stock)


def create_product(data):
    """`data` must already be validated (see forms.ProductForm)."""
    with transaction("products", "categories"):
        if not find_one("categories", category_id=data["category_id"]):
            raise ValidationError("Selected category does not exist.")
        rows = read_rows("products")
        if any(r["name"].lower() == data["name"].lower() for r in rows):
            raise ValidationError("A product with this name already exists.")
        product = Product(
            product_id=next_id("products", rows), name=data["name"],
            description=data["description"], category_id=data["category_id"],
            price=data["price"], stock=data["stock"], image_path=data["image_path"],
            created_at=now_iso(), is_active=True,
        )
        rows.append(product.to_row())
        write_rows("products", rows)
    return product


def update_product(product_id, data):
    with transaction("products", "categories"):
        if not find_one("categories", category_id=data["category_id"]):
            raise ValidationError("Selected category does not exist.")
        rows = read_rows("products")
        target = next((r for r in rows if r["product_id"] == product_id), None)
        if target is None:
            raise ValidationError("Product not found.")
        if any(r["name"].lower() == data["name"].lower() and r["product_id"] != product_id
               for r in rows):
            raise ValidationError("Another product already uses this name.")
        target.update({
            "name": data["name"], "description": data["description"],
            "category_id": data["category_id"], "price": f"{data['price']:.2f}",
            "stock": str(data["stock"]), "image_path": data["image_path"],
        })
        write_rows("products", rows)


def delete_product(product_id):
    """Delete a product. Products that appear in past orders are archived instead
    (is_active=0) so old orders keep valid references.  Returns 'deleted'/'archived'."""
    with transaction("products", "order_items", "reviews"):
        rows = read_rows("products")
        target = next((r for r in rows if r["product_id"] == product_id), None)
        if target is None:
            raise ValidationError("Product not found.")
        if any(i["product_id"] == product_id for i in read_rows("order_items")):
            target["is_active"] = "0"
            write_rows("products", rows)
            return "archived"
        write_rows("products", [r for r in rows if r["product_id"] != product_id])
        reviews = read_rows("reviews")
        write_rows("reviews", [r for r in reviews if r["product_id"] != product_id])
        return "deleted"


# ----------------------------------------------------------------- reviews ---
def list_reviews(product_id):
    names = {c["customer_id"]: c["name"] for c in read_rows("customers")}
    reviews = [r | {"customer_name": names.get(r["customer_id"], "Customer")}
               for r in read_rows("reviews") if r["product_id"] == product_id]
    return sorted(reviews, key=lambda r: r["created_at"], reverse=True)


def average_rating(reviews):
    if not reviews:
        return 0.0
    return round(sum(to_float(r["rating"]) for r in reviews) / len(reviews), 1)


def add_review(product_id, customer_id, rating, comment):
    """One review per customer per product (a new one replaces the old)."""
    with transaction("reviews", "products"):
        if not find_one("products", product_id=product_id):
            raise ValidationError("Product not found.")
        rows = read_rows("reviews")
        rows = [r for r in rows if not (r["product_id"] == product_id
                                        and r["customer_id"] == customer_id)]
        rows.append({"review_id": next_id("reviews", rows), "product_id": product_id,
                     "customer_id": customer_id, "rating": str(rating),
                     "comment": comment, "created_at": now_iso()})
        write_rows("reviews", rows)
