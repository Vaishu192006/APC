"""Django forms. Every field is validated again on the server with validators.py."""
from django import forms

from .services import product_service, validators as v


class BootstrapMixin:
    """Adds Bootstrap CSS classes to every widget."""

    def _style(self):
        for field in self.fields.values():
            widget = field.widget
            css = "form-select" if isinstance(widget, forms.Select) else "form-control"
            widget.attrs["class"] = f"{widget.attrs.get('class', '')} {css}".strip()


class RegisterForm(BootstrapMixin, forms.Form):
    name = forms.CharField(max_length=60, label="Full name")
    email = forms.CharField(max_length=100, label="Email", widget=forms.EmailInput)
    phone = forms.CharField(max_length=15, label="Mobile number")
    address = forms.CharField(max_length=200, required=False, label="Address (optional)",
                              widget=forms.Textarea(attrs={"rows": 2}))
    password = forms.CharField(label="Password", widget=forms.PasswordInput,
                               help_text="8+ characters with letters and digits.")
    confirm_password = forms.CharField(label="Confirm password", widget=forms.PasswordInput)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._style()

    def clean_name(self):
        return v.validate_name(self.cleaned_data["name"])

    def clean_email(self):
        return v.validate_email(self.cleaned_data["email"])

    def clean_phone(self):
        return v.validate_phone(self.cleaned_data["phone"])

    def clean_address(self):
        return v.validate_text(self.cleaned_data.get("address", ""), "Address", 200)

    def clean_password(self):
        return v.validate_password(self.cleaned_data["password"])

    def clean(self):
        data = super().clean()
        if data.get("password") and data.get("password") != data.get("confirm_password"):
            self.add_error("confirm_password", "Passwords do not match.")
        return data


class LoginForm(BootstrapMixin, forms.Form):
    email = forms.CharField(max_length=100, widget=forms.EmailInput)
    password = forms.CharField(widget=forms.PasswordInput)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._style()


class ProductForm(BootstrapMixin, forms.Form):
    name = forms.CharField(max_length=100)
    description = forms.CharField(max_length=500, widget=forms.Textarea(attrs={"rows": 3}))
    category_id = forms.ChoiceField(label="Category")
    price = forms.DecimalField(min_value=0, decimal_places=2, max_digits=10, label="Price")
    stock = forms.IntegerField(min_value=0, label="Stock quantity")
    image_path = forms.CharField(
        required=False, max_length=300, label="Image (optional)",
        help_text="An https:// link, or a path inside static/ such as shop/img/products/x.png. "
                  "Leave blank to use the placeholder.")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["category_id"].choices = [
            (c["category_id"], c["name"]) for c in product_service.list_categories()]
        self._style()

    def clean_name(self):
        return v.validate_product_name(self.cleaned_data["name"])

    def clean_description(self):
        return v.validate_text(self.cleaned_data["description"], "Description", 500, required=True)

    def clean_price(self):
        return v.validate_price(self.cleaned_data["price"])

    def clean_stock(self):
        return v.validate_stock(self.cleaned_data["stock"])

    def clean_image_path(self):
        return v.validate_image_path(self.cleaned_data.get("image_path", ""))


class CategoryForm(BootstrapMixin, forms.Form):
    name = forms.CharField(max_length=40)
    description = forms.CharField(max_length=150, required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._style()

    def clean_name(self):
        return v.validate_text(self.cleaned_data["name"], "Category name", 40, required=True)

    def clean_description(self):
        return v.validate_text(self.cleaned_data.get("description", ""), "Description", 150)


class ReviewForm(BootstrapMixin, forms.Form):
    rating = forms.ChoiceField(choices=[(i, f"{i} star{'s' if i > 1 else ''}") for i in range(5, 0, -1)])
    comment = forms.CharField(max_length=300, required=False, widget=forms.Textarea(attrs={"rows": 2}))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._style()

    def clean_rating(self):
        return v.validate_rating(self.cleaned_data["rating"])

    def clean_comment(self):
        return v.validate_text(self.cleaned_data.get("comment", ""), "Comment", 300)
