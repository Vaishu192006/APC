from django.urls import path

from .views import admin_views as admin, auth_views as auth, customer_views as cust

app_name = "shop"

urlpatterns = [
    # public
    path("", cust.home, name="home"),
    path("products/", cust.product_list, name="product_list"),
    path("products/<str:product_id>/", cust.product_detail, name="product_detail"),
    path("products/<str:product_id>/review/", cust.review_add, name="review_add"),
    # accounts
    path("register/", auth.register_view, name="register"),
    path("login/", auth.login_view, name="login"),
    path("logout/", auth.logout_view, name="logout"),
    # customer
    path("account/", cust.customer_dashboard, name="customer_dashboard"),
    path("cart/", cust.cart_view, name="cart"),
    path("cart/add/<str:product_id>/", cust.cart_add, name="cart_add"),
    path("cart/update/<str:product_id>/", cust.cart_update, name="cart_update"),
    path("cart/remove/<str:product_id>/", cust.cart_remove, name="cart_remove"),
    path("checkout/", cust.checkout, name="checkout"),
    path("orders/", cust.order_history, name="order_history"),
    path("orders/<str:order_id>/", cust.order_detail, name="order_detail"),
    path("orders/<str:order_id>/confirmation/", cust.order_confirmation, name="order_confirmation"),
    path("orders/<str:order_id>/cancel/", cust.order_cancel, name="order_cancel"),
    # admin
    path("manage/", admin.dashboard, name="admin_dashboard"),
    path("manage/analytics/", admin.analytics, name="admin_analytics"),
    path("manage/products/", admin.product_list, name="admin_products"),
    path("manage/products/add/", admin.product_add, name="admin_product_add"),
    path("manage/products/<str:product_id>/edit/", admin.product_edit, name="admin_product_edit"),
    path("manage/products/<str:product_id>/delete/", admin.product_delete, name="admin_product_delete"),
    path("manage/categories/", admin.categories, name="admin_categories"),
    path("manage/categories/<str:category_id>/delete/", admin.category_delete, name="admin_category_delete"),
    path("manage/orders/", admin.order_list, name="admin_orders"),
    path("manage/orders/<str:order_id>/", admin.order_detail, name="admin_order_detail"),
    path("manage/orders/<str:order_id>/status/", admin.order_status, name="admin_order_status"),
    path("manage/customers/", admin.customers, name="admin_customers"),
]
